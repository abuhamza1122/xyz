### 1) What is a vector?
#### a quantity having direction as well as magnitude, especially as determining the position of one point in space relative to another.

### 2) How do you represent vectors using a Python list? Give an example.



```python
# You can represent vectors in Python using lists, where each element of the list corresponds to a component of the vector.
#Here's an example of how to represent a 2D vector using a Python list:
# Representing a 2D vector [x, y]
vector_2d = [3, 4]  # This represents a 2D vector with x = 3 and y = 4

```

### 3) What is a dot product of two vectors?
#### The dot product, also called scalar product, is a measure of how closely two vectors align, in terms of the directions they point.

### 4) Write a function to compute the dot product of two vectors.



```python
def dot_product(vector1, vector2):
    if len(vector1) != len(vector2):
        raise ValueError("Vectors must have the same dimension for dot product calculation.")
    
    result = sum(v1 * v2 for v1, v2 in zip(vector1, vector2))
    return result

# Example usage:
vector1 = [3, 4, 5]
vector2 = [1, 2, 3]

result = dot_product(vector1, vector2)
print("Dot Product:", result)

```

    Dot Product: 26
    

### 5) what is numpy?
#### NumPy is a Python library used for working with arrays.

### 6) How do you install Numpy?
#### You have to write this in the command line "pip install numpy"


### 7) How do you import the numpy module?
#### import numpy

### 8) What does it mean to import a module with an alias? Give an example.
#### Import aliases are where you take your standard import, but instead of using a pre-defined name by the exporting module, you use a name that is defined in the importing module.


```python
import numpy as np
```

### 9) What is the commonly used alias for numpy?
#### NumPy is usually imported under the np alias. 

### 10) What is a Numpy array?
#### A numpy array is a grid of values, all of the same type, and is indexed by a tuple of nonnegative integers. 

### 11) How do you create a Numpy array? Give an example.



```python
# Once you have NumPy installed, you can create NumPy arrays using the numpy.array() function. Here's an example of how 
# to create a simple NumPy array:
import numpy as np

# Creating a NumPy array from a Python list
my_list = [1, 3, 5, 7, 9]
my_array = np.array(my_list)

print(my_array)

```

    [1 3 5 7 9]
    

### 12) What is the type of Numpy arrays?
#### booleans (bool), integers (int), unsigned integers (uint) floating point (float) and complex.

### 13) How do you access the elements of a Numpy array?


```python
# First, you need to import the numpy library, and then you can create an array using the numpy.array() function.
# Here's an example:
import numpy as np

# Create a NumPy array from a Python list
my_list = [12, 24, 36, 48, 60]
my_array = np.array(my_list)

print(my_array)

```

    [12 24 36 48 60]
    


```python
import numpy as np

# Create a 2D NumPy array from a list of lists
matrix = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])

print(matrix)

```

    [[1 2 3]
     [4 5 6]
     [7 8 9]]
    


```python
import numpy as np

arr = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])

print(arr[0, 1, 2])
```

    6
    

### 14) How do you compute the dot product of two vectors using Numpy?



```python
#  We can compute the dot product of two vectors using NumPy's numpy.dot() function or the @ operator for element-wise
# multiplication. Here is only one example:

#  Using numpy.dot()
import numpy as np

# Define two NumPy arrays representing vectors
vector1 = np.array([10, 12, 43])
vector2 = np.array([41, 25, 36])

# Compute the dot product using numpy.dot()
dot_product = np.dot(vector1, vector2)

print("Dot Product (Method 1):", dot_product)

```

    Dot Product (Method 1): 2258
    

### 15) What happens if you try to compute the dot product of two vectors which have different sizes?
#### The dot product is applicable only for the pairs of vectors that have the same number of dimensions.

### 16) How do you compute the element-wise product of two Numpy arrays?


```python
import numpy as np

# Define two NumPy arrays
array1 = np.array([11, 22, 53])
array2 = np.array([49, 55, 64])

# Compute the element-wise product using the * operator
elementwise_product = array1 * array2

print("Element-Wise Product:", elementwise_product)

```

    Element-Wise Product: [ 539 1210 3392]
    

### 17) How do you compute the sum of all the elements in a Numpy array?



```python
import numpy as np

# Define a NumPy array
my_array = np.array([1, 2, 3, 4, 5])

# Compute the sum using the array.sum() method
array_sum = my_array.sum()

print("Sum :", array_sum)

```

    Sum : 15
    

### 18) What are the benefits of using Numpy arrays over Python lists for operating on numerical data?
#### NumPy arrays are faster than Python lists.

### 19) Why do Numpy array operations have better performance compared to Python functions and loops?
#### A Python list, however, is only a collection of objects. A NumPy array allows only homogeneous data types. 

### 20) Illustrate the performance difference between Numpy array operations and Python loops using an example.



```python
import numpy as np
import time

# Create large arrays with 10 million elements
array_size = 10**7
numpy_array = np.arange(array_size)
python_list = list(range(array_size))

# Using NumPy for element-wise multiplication
start_time = time.time()
numpy_result = numpy_array * numpy_array
numpy_time = time.time() - start_time

# Using Python loop for element-wise multiplication
start_time = time.time()
python_result = [x * x for x in python_list]
python_time = time.time() - start_time

# Check if the results match
results_match = np.array_equal(numpy_result, python_result)

print(f"NumPy Execution Time: {numpy_time:.6f} seconds")
print(f"Python Loop Execution Time: {python_time:.6f} seconds")
print("Results Match:", results_match)

```

    NumPy Execution Time: 0.017989 seconds
    Python Loop Execution Time: 0.968157 seconds
    Results Match: False
    

### 21) What are multi-dimensional Numpy arrays?
#### A multi-dimensional array is an array with more than one level or dimension.

### 22) Illustrate the creation of Numpy arrays with 2, 3, and 4 dimensions.


```python
# 2-D dimensions
import numpy as np

arr = np.array([[2, 4, 6], [8, 10, 12]])

print(arr)
print('number of dimensions :', arr.ndim)
```

    [[ 2  4  6]
     [ 8 10 12]]
    number of dimensions : 2
    


```python
# 3-D dimensions
import numpy as np

arr = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])

print(arr)
print('number of dimensions :', arr.ndim)
```

    [[[ 1  2  3]
      [ 4  5  6]]
    
     [[ 7  8  9]
      [10 11 12]]]
    number of dimensions : 3
    


```python
# 4-D dimensions
import numpy as np

arr = np.array([10, 20, 30, 44], ndmin=4)

print(arr)
print('number of dimensions :', arr.ndim)
```

    [[[[10 20 30 44]]]]
    number of dimensions : 4
    

### 23) How do you inspect the number of dimensions and the length along each dimension in a Numpy array?



```python
import numpy as np

# Create a NumPy array
my_array = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])

# Inspect the number of dimensions
num_dimensions = my_array.ndim

# Inspect the length along each dimension
dimensions = my_array.shape

print("Number of Dimensions:", num_dimensions)
print("Length along Each Dimension:", dimensions)

```

    Number of Dimensions: 2
    Length along Each Dimension: (3, 3)
    

### 24) Can the elements of a Numpy array have different data types?
#### The elements of a NumPy array must all be of the same type

### 25) How do you check the data type of the elements of a Numpy array?


```python
import numpy as np

arr = np.array([13, 26, 39, 52], ndmin=5)

print(arr.dtype)
```

    int32
    

### 26) What is the data type of a Numpy array?
#### Here's the list of most commonly used numeric data types in NumPy: int8 , int16 , int32 , int64 - signed integer types with different bit sizes.

### 27) What is the difference between a matrix and a 2D Numpy array?
#### Numpy arrays (nd-arrays) are N-dimensional where, N=1,2,3… Numpy matrices are strictly 2-dimensional. 

### 28) How do you perform matrix multiplication using Numpy?


```python
import numpy as np

X = 5

Y = [[1, 7],
      [6, 10]]
 
print(np.dot(X,Y))
```

    [[ 5 35]
     [30 50]]
    

### 29) What is the @ operator used for in Numpy?
#### The @ operator, available since Python 3.5, can be used for conventional matrix multiplication.

### 30) What is the CSV file format?
#### A CSV file is a spreadsheet format, so it can be opened by spreadsheet applications like Microsoft Excel and Google Spreadsheets. Since CSV files are used to exchange large volumes of data, database programs, analytical software, and applications that can store massive amounts of information usually support the CSV.

### 31) How do you read data from a CSV file using Numpy?


```python
import numpy as np
 
# using loadtxt()
arr = np.loadtxt("sample_data.csv",
                 delimiter=",", dtype=str)
display(arr)
```


    ---------------------------------------------------------------------------

    FileNotFoundError                         Traceback (most recent call last)

    Cell In[23], line 4
          1 import numpy as np
          3 # using loadtxt()
    ----> 4 arr = np.loadtxt("sample_data.csv",
          5                  delimiter=",", dtype=str)
          6 display(arr)
    

    File C:\ProgramData\anaconda3\Lib\site-packages\numpy\lib\npyio.py:1356, in loadtxt(fname, dtype, comments, delimiter, converters, skiprows, usecols, unpack, ndmin, encoding, max_rows, quotechar, like)
       1353 if isinstance(delimiter, bytes):
       1354     delimiter = delimiter.decode('latin1')
    -> 1356 arr = _read(fname, dtype=dtype, comment=comment, delimiter=delimiter,
       1357             converters=converters, skiplines=skiprows, usecols=usecols,
       1358             unpack=unpack, ndmin=ndmin, encoding=encoding,
       1359             max_rows=max_rows, quote=quotechar)
       1361 return arr
    

    File C:\ProgramData\anaconda3\Lib\site-packages\numpy\lib\npyio.py:975, in _read(fname, delimiter, comment, quote, imaginary_unit, usecols, skiplines, max_rows, converters, ndmin, unpack, dtype, encoding)
        973     fname = os.fspath(fname)
        974 if isinstance(fname, str):
    --> 975     fh = np.lib._datasource.open(fname, 'rt', encoding=encoding)
        976     if encoding is None:
        977         encoding = getattr(fh, 'encoding', 'latin1')
    

    File C:\ProgramData\anaconda3\Lib\site-packages\numpy\lib\_datasource.py:193, in open(path, mode, destpath, encoding, newline)
        156 """
        157 Open `path` with `mode` and return the file object.
        158 
       (...)
        189 
        190 """
        192 ds = DataSource(destpath)
    --> 193 return ds.open(path, mode, encoding=encoding, newline=newline)
    

    File C:\ProgramData\anaconda3\Lib\site-packages\numpy\lib\_datasource.py:533, in DataSource.open(self, path, mode, encoding, newline)
        530     return _file_openers[ext](found, mode=mode,
        531                               encoding=encoding, newline=newline)
        532 else:
    --> 533     raise FileNotFoundError(f"{path} not found.")
    

    FileNotFoundError: sample_data.csv not found.



```python
import numpy as np
 
# using genfromtxt()
arr = np.genfromtxt("sample_data.csv",
                    delimiter=",", dtype=str)
display(arr)
```


    ---------------------------------------------------------------------------

    FileNotFoundError                         Traceback (most recent call last)

    Cell In[24], line 4
          1 import numpy as np
          3 # using genfromtxt()
    ----> 4 arr = np.genfromtxt("sample_data.csv",
          5                     delimiter=",", dtype=str)
          6 display(arr)
    

    File C:\ProgramData\anaconda3\Lib\site-packages\numpy\lib\npyio.py:1977, in genfromtxt(fname, dtype, comments, delimiter, skip_header, skip_footer, converters, missing_values, filling_values, usecols, names, excludelist, deletechars, replace_space, autostrip, case_sensitive, defaultfmt, unpack, usemask, loose, invalid_raise, max_rows, encoding, ndmin, like)
       1975     fname = os_fspath(fname)
       1976 if isinstance(fname, str):
    -> 1977     fid = np.lib._datasource.open(fname, 'rt', encoding=encoding)
       1978     fid_ctx = contextlib.closing(fid)
       1979 else:
    

    File C:\ProgramData\anaconda3\Lib\site-packages\numpy\lib\_datasource.py:193, in open(path, mode, destpath, encoding, newline)
        156 """
        157 Open `path` with `mode` and return the file object.
        158 
       (...)
        189 
        190 """
        192 ds = DataSource(destpath)
    --> 193 return ds.open(path, mode, encoding=encoding, newline=newline)
    

    File C:\ProgramData\anaconda3\Lib\site-packages\numpy\lib\_datasource.py:533, in DataSource.open(self, path, mode, encoding, newline)
        530     return _file_openers[ext](found, mode=mode,
        531                               encoding=encoding, newline=newline)
        532 else:
    --> 533     raise FileNotFoundError(f"{path} not found.")
    

    FileNotFoundError: sample_data.csv not found.


### 32) How do you concatenate two Numpy arrays?


```python
import numpy as np

# Create two NumPy arrays
array1 = np.array([2, 4, 6])
array2 = np.array([5, 3, 1])

# Concatenate the arrays along axis 0 (default, results in a new 1D array)
concatenated_array = np.concatenate((array1, array2))

print("Concatenated Array:")
print(concatenated_array)

```

    Concatenated Array:
    [2 4 6 5 3 1]
    

### 33) What is the purpose of the axis argument of np.concatenate?
#### Numpy concatenate is like “stacking” numpy arrays
#### The axis that we specify with the axis parameter is the axis along which we stack the arrays. 

### 34) When are two Numpy arrays compatible for concatenation?
#### The arrays must have the same shape, except in the dimension corresponding to axis.

### 35) Give an example of two Numpy arrays that can be concatenated.



```python
import numpy as np

# Create two NumPy arrays with the same number of columns (2D arrays)
array1 = np.array([[1, 2], [3, 4]])
array2 = np.array([[5, 6], [7, 8]])

# Concatenate the arrays along rows (axis=0)
concatenated_array = np.concatenate((array1, array2), axis=0)

print("Concatenated 2D Array (along rows, axis=0):")
print(concatenated_array)


```

    Concatenated 2D Array (along rows, axis=0):
    [[1 2]
     [3 4]
     [5 6]
     [7 8]]
    

### 36) Give an example of two Numpy arrays that cannot be concatenated.



```python
x = np.array([11, 22])
y = np.array([36, 44])
np.concatenate(x, y)

# TypeError: only length-1 arrays can be converted to Python scalars
```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    Cell In[28], line 3
          1 x = np.array([11, 22])
          2 y = np.array([36, 44])
    ----> 3 np.concatenate(x, y)
    

    File <__array_function__ internals>:200, in concatenate(*args, **kwargs)
    

    TypeError: only integer scalar arrays can be converted to a scalar index


### 37) What is the purpose of the np.reshape function?
#### Change an Array's Shape Using NumPy reshape() NumPy's reshape() enables you to change the shape of an array into another compatible shape. 

### 38) What does it mean to “reshape” a Numpy array?
#### Reshaping means changing the shape of an array. The shape of an array is the number of elements in each dimension. By reshaping we can add or remove dimensions or change number of elements in each dimension.

### 39) How do you write a numpy array into a CSV file?



```python
# save numpy array as csv file
from numpy import asarray
from numpy import savetxt
# define data
data = asarray([[ 10, 20, 30, 40, 50, 60, 70, 80, 90]])
# save to csv file
savetxt('data.csv', data, delimiter=',')
```

### 40) Give some examples of Numpy functions for performing mathematical operations.


```python
import numpy as np

# Example 1: Basic Arithmetic Operations
arr1 = np.array([1, 2, 3])
arr2 = np.array([4, 5, 6])
addition = np.add(arr1, arr2)
subtraction = np.subtract(arr1, arr2)
multiplication = np.multiply(arr1, arr2)
division = np.divide(arr1, arr2)

# Example 2: Trigonometric Functions
angles = np.array([0, np.pi/4, np.pi/2])
sin_values = np.sin(angles)
cos_values = np.cos(angles)

# Example 3: Logarithmic and Exponential Functions
arr3 = np.array([1, 10, 100])
log_values = np.log(arr3)
exp_values = np.exp(arr3)

# Example 4: Linear Algebra
matrix1 = np.array([[1, 2], [3, 4]])
matrix2 = np.array([[5, 6], [7, 8]])
dot_product = np.dot(matrix1, matrix2)
matrix_multiply = np.matmul(matrix1, matrix2)

print("Example 1 - Addition:", addition)
print("Example 1 - Subtraction:", subtraction)
print("Example 1 - Multiplication:", multiplication)
print("Example 1 - Division:", division)

print("Example 2 - Sine Values:", sin_values)
print("Example 2 - Cosine Values:", cos_values)

print("Example 3 - Natural Logarithm:", log_values)
print("Example 3 - Exponential Values:", exp_values)

print("Example 4 - Dot Product:", dot_product)
print("Example 4 - Matrix Multiplication:\n", matrix_multiply)

```

    Example 1 - Addition: [5 7 9]
    Example 1 - Subtraction: [-3 -3 -3]
    Example 1 - Multiplication: [ 4 10 18]
    Example 1 - Division: [0.25 0.4  0.5 ]
    Example 2 - Sine Values: [0.         0.70710678 1.        ]
    Example 2 - Cosine Values: [1.00000000e+00 7.07106781e-01 6.12323400e-17]
    Example 3 - Natural Logarithm: [0.         2.30258509 4.60517019]
    Example 3 - Exponential Values: [2.71828183e+00 2.20264658e+04 2.68811714e+43]
    Example 4 - Dot Product: [[19 22]
     [43 50]]
    Example 4 - Matrix Multiplication:
     [[19 22]
     [43 50]]
    

### 41) Give some examples of Numpy functions for performing array manipulation.



```python
import numpy as np

# Create two arrays for demonstration
arr1 = np.array([[1, 2, 3], [4, 5, 6]])
arr2 = np.array([[7, 8, 9], [10, 11, 12]])

# Reshaping Arrays
reshaped_arr = np.reshape(arr1, (3, 2))
transposed_arr = np.transpose(arr1)

# Concatenation and Stacking
concatenated_arr = np.concatenate((arr1, arr2), axis=0)
stacked_vertically = np.vstack((arr1, arr2))
stacked_horizontally = np.hstack((arr1, arr2))

# Splitting Arrays
split_arr = np.split(reshaped_arr, 3)
vsplit_arr = np.vsplit(concatenated_arr, 2)
hsplit_arr = np.hsplit(concatenated_arr, 3)

# Sorting
sorted_arr = np.sort(arr1, axis=None)

print("Original Array 1:\n", arr1)
print("Reshaped Array:\n", reshaped_arr)
print("Transposed Array 1:\n", transposed_arr)
print("Concatenated Array:\n", concatenated_arr)
print("Vertically Stacked Array:\n", stacked_vertically)
print("Horizontally Stacked Array:\n", stacked_horizontally)
print("Split Arrays:\n", split_arr)
print("Vertically Split Arrays:\n", vsplit_arr)
print("Horizontally Split Arrays:\n", hsplit_arr)
print("Sorted Array 1:\n", sorted_arr)

```

    Original Array 1:
     [[1 2 3]
     [4 5 6]]
    Reshaped Array:
     [[1 2]
     [3 4]
     [5 6]]
    Transposed Array 1:
     [[1 4]
     [2 5]
     [3 6]]
    Concatenated Array:
     [[ 1  2  3]
     [ 4  5  6]
     [ 7  8  9]
     [10 11 12]]
    Vertically Stacked Array:
     [[ 1  2  3]
     [ 4  5  6]
     [ 7  8  9]
     [10 11 12]]
    Horizontally Stacked Array:
     [[ 1  2  3  7  8  9]
     [ 4  5  6 10 11 12]]
    Split Arrays:
     [array([[1, 2]]), array([[3, 4]]), array([[5, 6]])]
    Vertically Split Arrays:
     [array([[1, 2, 3],
           [4, 5, 6]]), array([[ 7,  8,  9],
           [10, 11, 12]])]
    Horizontally Split Arrays:
     [array([[ 1],
           [ 4],
           [ 7],
           [10]]), array([[ 2],
           [ 5],
           [ 8],
           [11]]), array([[ 3],
           [ 6],
           [ 9],
           [12]])]
    Sorted Array 1:
     [1 2 3 4 5 6]
    

### 42) Give some examples of Numpy functions for performing linear algebra.



```python
import numpy as np

# Example matrices
A = np.array([[1, 2], [3, 4]])
B = np.array([[5, 6], [7, 8]])
x = np.array([1, 2])

# Matrix multiplication
result_dot = np.dot(A, B)
result_matmul = np.matmul(A, B)
result_at_operator = A @ B

# Matrix inverse and determinant
inv_A = np.linalg.inv(A)
det_A = np.linalg.det(A)

# Eigenvalues and eigenvectors
eigenvalues, eigenvectors = np.linalg.eig(A)

# Singular Value Decomposition (SVD)
U, S, VT = np.linalg.svd(A)

# Linear equation solving
coeff_matrix = np.array([[2, 3], [1, -2]])
constants = np.array([8, 1])
solution = np.linalg.solve(coeff_matrix, constants)

# Matrix norms
Frobenius_norm = np.linalg.norm(A, 'fro')
L2_norm_vector = np.linalg.norm(x, ord=2)

print("Matrix Multiplication (Dot):", result_dot)
print("Matrix Multiplication (Matmul):", result_matmul)
print("Matrix Multiplication (@ Operator):", result_at_operator)
print("Matrix Inverse:", inv_A)
print("Determinant of A:", det_A)
print("Eigenvalues of A:", eigenvalues)
print("Eigenvectors of A:", eigenvectors)
print("Singular Value Decomposition - U:", U)
print("Singular Value Decomposition - S:", S)
print("Singular Value Decomposition - VT:", VT)
print("Linear Equation Solution:", solution)
print("Frobenius Norm of A:", Frobenius_norm)
print("L2 Norm of x:", L2_norm_vector)

```

    Matrix Multiplication (Dot): [[19 22]
     [43 50]]
    Matrix Multiplication (Matmul): [[19 22]
     [43 50]]
    Matrix Multiplication (@ Operator): [[19 22]
     [43 50]]
    Matrix Inverse: [[-2.   1. ]
     [ 1.5 -0.5]]
    Determinant of A: -2.0000000000000004
    Eigenvalues of A: [-0.37228132  5.37228132]
    Eigenvectors of A: [[-0.82456484 -0.41597356]
     [ 0.56576746 -0.90937671]]
    Singular Value Decomposition - U: [[-0.40455358 -0.9145143 ]
     [-0.9145143   0.40455358]]
    Singular Value Decomposition - S: [5.4649857  0.36596619]
    Singular Value Decomposition - VT: [[-0.57604844 -0.81741556]
     [ 0.81741556 -0.57604844]]
    Linear Equation Solution: [2.71428571 0.85714286]
    Frobenius Norm of A: 5.477225575051661
    L2 Norm of x: 2.23606797749979
    

### 43) Give some examples of Numpy functions for performing statistical operations.



```python
import numpy as np

# Example data
data = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

# Mean and Median
mean = np.mean(data)
median = np.median(data)

# Variance and Standard Deviation
variance = np.var(data)
std_deviation = np.std(data)

# Min and Max
min_value = np.min(data)
max_value = np.max(data)

# Sum and Product
sum_values = np.sum(data)
product_values = np.prod(data)

print("Mean:", mean)
print("Median:", median)
print("Variance:", variance)
print("Standard Deviation:", std_deviation)
print("Min Value:", min_value)
print("Max Value:", max_value)
print("Sum of Values:", sum_values)
print("Product of Values:", product_values)

```

    Mean: 5.5
    Median: 5.5
    Variance: 8.25
    Standard Deviation: 2.8722813232690143
    Min Value: 1
    Max Value: 10
    Sum of Values: 55
    Product of Values: 3628800
    

### 44) How do you find the right Numpy function for a specific operation or use case?



```python
import numpy as np

# Example array of data
data = np.array([10, 20, 30, 40, 50])

# Calculate the standard deviation
std_deviation = np.std(data)

print("Standard Deviation:", std_deviation)

```

    Standard Deviation: 14.142135623730951
    

### 45) Where can you see a list of all the Numpy array functions and operations?



```python
import numpy as np
dir(np)
```




    ['ALLOW_THREADS',
     'AxisError',
     'BUFSIZE',
     'CLIP',
     'ComplexWarning',
     'DataSource',
     'ERR_CALL',
     'ERR_DEFAULT',
     'ERR_IGNORE',
     'ERR_LOG',
     'ERR_PRINT',
     'ERR_RAISE',
     'ERR_WARN',
     'FLOATING_POINT_SUPPORT',
     'FPE_DIVIDEBYZERO',
     'FPE_INVALID',
     'FPE_OVERFLOW',
     'FPE_UNDERFLOW',
     'False_',
     'Inf',
     'Infinity',
     'MAXDIMS',
     'MAY_SHARE_BOUNDS',
     'MAY_SHARE_EXACT',
     'ModuleDeprecationWarning',
     'NAN',
     'NINF',
     'NZERO',
     'NaN',
     'PINF',
     'PZERO',
     'RAISE',
     'RankWarning',
     'SHIFT_DIVIDEBYZERO',
     'SHIFT_INVALID',
     'SHIFT_OVERFLOW',
     'SHIFT_UNDERFLOW',
     'ScalarType',
     'Tester',
     'TooHardError',
     'True_',
     'UFUNC_BUFSIZE_DEFAULT',
     'UFUNC_PYVALS_NAME',
     'VisibleDeprecationWarning',
     'WRAP',
     '_CopyMode',
     '_NoValue',
     '_UFUNC_API',
     '__NUMPY_SETUP__',
     '__all__',
     '__builtins__',
     '__cached__',
     '__config__',
     '__deprecated_attrs__',
     '__dir__',
     '__doc__',
     '__expired_functions__',
     '__file__',
     '__former_attrs__',
     '__future_scalars__',
     '__getattr__',
     '__git_version__',
     '__loader__',
     '__mkl_version__',
     '__name__',
     '__package__',
     '__path__',
     '__spec__',
     '__version__',
     '_add_newdoc_ufunc',
     '_builtins',
     '_distributor_init',
     '_financial_names',
     '_get_promotion_state',
     '_globals',
     '_int_extended_msg',
     '_mat',
     '_no_nep50_warning',
     '_pyinstaller_hooks_dir',
     '_pytesttester',
     '_set_promotion_state',
     '_specific_msg',
     '_version',
     'abs',
     'absolute',
     'add',
     'add_docstring',
     'add_newdoc',
     'add_newdoc_ufunc',
     'all',
     'allclose',
     'alltrue',
     'amax',
     'amin',
     'angle',
     'any',
     'append',
     'apply_along_axis',
     'apply_over_axes',
     'arange',
     'arccos',
     'arccosh',
     'arcsin',
     'arcsinh',
     'arctan',
     'arctan2',
     'arctanh',
     'argmax',
     'argmin',
     'argpartition',
     'argsort',
     'argwhere',
     'around',
     'array',
     'array2string',
     'array_equal',
     'array_equiv',
     'array_repr',
     'array_split',
     'array_str',
     'asanyarray',
     'asarray',
     'asarray_chkfinite',
     'ascontiguousarray',
     'asfarray',
     'asfortranarray',
     'asmatrix',
     'atleast_1d',
     'atleast_2d',
     'atleast_3d',
     'average',
     'bartlett',
     'base_repr',
     'binary_repr',
     'bincount',
     'bitwise_and',
     'bitwise_not',
     'bitwise_or',
     'bitwise_xor',
     'blackman',
     'block',
     'bmat',
     'bool_',
     'broadcast',
     'broadcast_arrays',
     'broadcast_shapes',
     'broadcast_to',
     'busday_count',
     'busday_offset',
     'busdaycalendar',
     'byte',
     'byte_bounds',
     'bytes_',
     'c_',
     'can_cast',
     'cast',
     'cbrt',
     'cdouble',
     'ceil',
     'cfloat',
     'char',
     'character',
     'chararray',
     'choose',
     'clip',
     'clongdouble',
     'clongfloat',
     'column_stack',
     'common_type',
     'compare_chararrays',
     'compat',
     'complex128',
     'complex64',
     'complex_',
     'complexfloating',
     'compress',
     'concatenate',
     'conj',
     'conjugate',
     'convolve',
     'copy',
     'copysign',
     'copyto',
     'corrcoef',
     'correlate',
     'cos',
     'cosh',
     'count_nonzero',
     'cov',
     'cross',
     'csingle',
     'ctypeslib',
     'cumprod',
     'cumproduct',
     'cumsum',
     'datetime64',
     'datetime_as_string',
     'datetime_data',
     'deg2rad',
     'degrees',
     'delete',
     'deprecate',
     'deprecate_with_doc',
     'diag',
     'diag_indices',
     'diag_indices_from',
     'diagflat',
     'diagonal',
     'diff',
     'digitize',
     'disp',
     'divide',
     'divmod',
     'dot',
     'double',
     'dsplit',
     'dstack',
     'dtype',
     'e',
     'ediff1d',
     'einsum',
     'einsum_path',
     'emath',
     'empty',
     'empty_like',
     'equal',
     'errstate',
     'euler_gamma',
     'exp',
     'exp2',
     'expand_dims',
     'expm1',
     'extract',
     'eye',
     'fabs',
     'fastCopyAndTranspose',
     'fft',
     'fill_diagonal',
     'find_common_type',
     'finfo',
     'fix',
     'flatiter',
     'flatnonzero',
     'flexible',
     'flip',
     'fliplr',
     'flipud',
     'float16',
     'float32',
     'float64',
     'float_',
     'float_power',
     'floating',
     'floor',
     'floor_divide',
     'fmax',
     'fmin',
     'fmod',
     'format_float_positional',
     'format_float_scientific',
     'format_parser',
     'frexp',
     'from_dlpack',
     'frombuffer',
     'fromfile',
     'fromfunction',
     'fromiter',
     'frompyfunc',
     'fromregex',
     'fromstring',
     'full',
     'full_like',
     'gcd',
     'generic',
     'genfromtxt',
     'geomspace',
     'get_array_wrap',
     'get_include',
     'get_printoptions',
     'getbufsize',
     'geterr',
     'geterrcall',
     'geterrobj',
     'gradient',
     'greater',
     'greater_equal',
     'half',
     'hamming',
     'hanning',
     'heaviside',
     'histogram',
     'histogram2d',
     'histogram_bin_edges',
     'histogramdd',
     'hsplit',
     'hstack',
     'hypot',
     'i0',
     'identity',
     'iinfo',
     'imag',
     'in1d',
     'index_exp',
     'indices',
     'inexact',
     'inf',
     'info',
     'infty',
     'inner',
     'insert',
     'int16',
     'int32',
     'int64',
     'int8',
     'int_',
     'intc',
     'integer',
     'interp',
     'intersect1d',
     'intp',
     'invert',
     'is_busday',
     'isclose',
     'iscomplex',
     'iscomplexobj',
     'isfinite',
     'isfortran',
     'isin',
     'isinf',
     'isnan',
     'isnat',
     'isneginf',
     'isposinf',
     'isreal',
     'isrealobj',
     'isscalar',
     'issctype',
     'issubclass_',
     'issubdtype',
     'issubsctype',
     'iterable',
     'ix_',
     'kaiser',
     'kron',
     'lcm',
     'ldexp',
     'left_shift',
     'less',
     'less_equal',
     'lexsort',
     'lib',
     'linalg',
     'linspace',
     'little_endian',
     'load',
     'loadtxt',
     'log',
     'log10',
     'log1p',
     'log2',
     'logaddexp',
     'logaddexp2',
     'logical_and',
     'logical_not',
     'logical_or',
     'logical_xor',
     'logspace',
     'longcomplex',
     'longdouble',
     'longfloat',
     'longlong',
     'lookfor',
     'ma',
     'mask_indices',
     'mat',
     'math',
     'matmul',
     'matrix',
     'max',
     'maximum',
     'maximum_sctype',
     'may_share_memory',
     'mean',
     'median',
     'memmap',
     'meshgrid',
     'mgrid',
     'min',
     'min_scalar_type',
     'minimum',
     'mintypecode',
     'mkl',
     'mod',
     'modf',
     'moveaxis',
     'msort',
     'multiply',
     'nan',
     'nan_to_num',
     'nanargmax',
     'nanargmin',
     'nancumprod',
     'nancumsum',
     'nanmax',
     'nanmean',
     'nanmedian',
     'nanmin',
     'nanpercentile',
     'nanprod',
     'nanquantile',
     'nanstd',
     'nansum',
     'nanvar',
     'nbytes',
     'ndarray',
     'ndenumerate',
     'ndim',
     'ndindex',
     'nditer',
     'negative',
     'nested_iters',
     'newaxis',
     'nextafter',
     'nonzero',
     'not_equal',
     'numarray',
     'number',
     'obj2sctype',
     'object_',
     'ogrid',
     'oldnumeric',
     'ones',
     'ones_like',
     'outer',
     'packbits',
     'pad',
     'partition',
     'percentile',
     'pi',
     'piecewise',
     'place',
     'poly',
     'poly1d',
     'polyadd',
     'polyder',
     'polydiv',
     'polyfit',
     'polyint',
     'polymul',
     'polynomial',
     'polysub',
     'polyval',
     'positive',
     'power',
     'printoptions',
     'prod',
     'product',
     'promote_types',
     'ptp',
     'put',
     'put_along_axis',
     'putmask',
     'quantile',
     'r_',
     'rad2deg',
     'radians',
     'random',
     'ravel',
     'ravel_multi_index',
     'real',
     'real_if_close',
     'rec',
     'recarray',
     'recfromcsv',
     'recfromtxt',
     'reciprocal',
     'record',
     'remainder',
     'repeat',
     'require',
     'reshape',
     'resize',
     'result_type',
     'right_shift',
     'rint',
     'roll',
     'rollaxis',
     'roots',
     'rot90',
     'round',
     'round_',
     'row_stack',
     's_',
     'safe_eval',
     'save',
     'savetxt',
     'savez',
     'savez_compressed',
     'sctype2char',
     'sctypeDict',
     'sctypes',
     'searchsorted',
     'select',
     'set_numeric_ops',
     'set_printoptions',
     'set_string_function',
     'setbufsize',
     'setdiff1d',
     'seterr',
     'seterrcall',
     'seterrobj',
     'setxor1d',
     'shape',
     'shares_memory',
     'short',
     'show_config',
     'show_runtime',
     'sign',
     'signbit',
     'signedinteger',
     'sin',
     'sinc',
     'single',
     'singlecomplex',
     'sinh',
     'size',
     'sometrue',
     'sort',
     'sort_complex',
     'source',
     'spacing',
     'split',
     'sqrt',
     'square',
     'squeeze',
     'stack',
     'std',
     'str_',
     'string_',
     'subtract',
     'sum',
     'swapaxes',
     'take',
     'take_along_axis',
     'tan',
     'tanh',
     'tensordot',
     'test',
     'testing',
     'tile',
     'timedelta64',
     'trace',
     'tracemalloc_domain',
     'transpose',
     'trapz',
     'tri',
     'tril',
     'tril_indices',
     'tril_indices_from',
     'trim_zeros',
     'triu',
     'triu_indices',
     'triu_indices_from',
     'true_divide',
     'trunc',
     'typecodes',
     'typename',
     'ubyte',
     'ufunc',
     'uint',
     'uint16',
     'uint32',
     'uint64',
     'uint8',
     'uintc',
     'uintp',
     'ulonglong',
     'unicode_',
     'union1d',
     'unique',
     'unpackbits',
     'unravel_index',
     'unsignedinteger',
     'unwrap',
     'use_hugepage',
     'ushort',
     'vander',
     'var',
     'vdot',
     'vectorize',
     'version',
     'void',
     'vsplit',
     'vstack',
     'where',
     'who',
     'zeros',
     'zeros_like']



### 46) What are the arithmetic operators supported by Numpy arrays? Illustrate with examples.


```python
import numpy as np

first_array = np.array([1, 3, 5, 7])
second_array = np.array([2, 4, 6, 8])

# using the + operator
result1 = first_array + second_array
print("Using the + operator:",result1) 

# using the add() function
result2 = np.add(first_array, second_array)
print("Using the add() function:",result2)
```

    Using the + operator: [ 3  7 11 15]
    Using the add() function: [ 3  7 11 15]
    


```python
import numpy as np

first_array = np.array([3, 9, 27, 81])
second_array = np.array([2, 4, 8, 16])

# using the - operator
result1 = first_array - second_array
print("Using the - operator:",result1) 

# using the subtract() function
result2 = np.subtract(first_array, second_array)
print("Using the subtract() function:",result2) 
```

    Using the - operator: [ 1  5 19 65]
    Using the subtract() function: [ 1  5 19 65]
    


```python
import numpy as np

first_array = np.array([1, 3, 5, 7])
second_array = np.array([2, 4, 6, 8])

# using the * operator
result1 = first_array * second_array
print("Using the * operator:",result1) 

# using the multiply() function
result2 = np.multiply(first_array, second_array)
print("Using the multiply() function:",result2) 
```

    Using the * operator: [ 2 12 30 56]
    Using the multiply() function: [ 2 12 30 56]
    


```python
import numpy as np

first_array = np.array([1, 2, 3])
second_array = np.array([4, 5, 6])

# using the / operator
result1 = first_array / second_array
print("Using the / operator:",result1) 

# using the divide() function
result2 = np.divide(first_array, second_array)
print("Using the divide() function:",result2) 
```

    Using the / operator: [0.25 0.4  0.5 ]
    Using the divide() function: [0.25 0.4  0.5 ]
    


```python
import numpy as np

array1 = np.array([1, 2, 3])

# using the ** operator
result1 = array1 ** 2
print("Using the ** operator:",result1) 

# using the power() function
result2 = np.power(array1, 2)
print("Using the power() function:",result2) 
```

    Using the ** operator: [1 4 9]
    Using the power() function: [1 4 9]
    


```python
import numpy as np

first_array = np.array([9, 10, 20])
second_array = np.array([2, 5, 7])

# using the % operator
result1 = first_array % second_array
print("Using the % operator:",result1) 

# using the mod() function
result2 = np.mod(first_array, second_array)
print("Using the mod() function:",result2)
```

    Using the % operator: [1 0 6]
    Using the mod() function: [1 0 6]
    

### 47) What is array broadcasting? How is it useful? Illustrate with an example.
#### The term broadcasting describes how numpy treats arrays with different shapes during arithmetic operations.
#### Broadcasting provides a means of vectorizing array operations so that looping occurs in C instead of Python. It does this without making needless copies of data and usually leads to efficient algorithm implementations.

### 48) Give some examples of arrays that are compatible for broadcasting? 


```python
import numpy as np

# Create a 1D array
arr = np.array([1, 2, 3, 4, 5])

# Add a scalar to the array
result = arr + 10

print(result)


```

    [11 12 13 14 15]
    

### 49) Give some examples of arrays that are not compatible for broadcasting?



```python
import numpy as np

arr1 = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])  # 3x3 array
arr2 = np.array([[10, 20], [30, 40]])  # 2x2 array

result = arr1 + arr2  # Broadcasting not possible

```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[42], line 6
          3 arr1 = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])  # 3x3 array
          4 arr2 = np.array([[10, 20], [30, 40]])  # 2x2 array
    ----> 6 result = arr1 + arr2
    

    ValueError: operands could not be broadcast together with shapes (3,3) (2,2) 


### 50) What are the comparison operators supported by Numpy arrays? Illustrate with examples.



```python
import numpy as np

# Create two NumPy arrays
arr1 = np.array([1, 2, 3, 4, 5])
arr2 = np.array([3, 2, 1, 4, 5])

# Element-wise comparisons
equal_to = arr1 == arr2
not_equal_to = arr1 != arr2
less_than = arr1 < arr2
less_than_or_equal_to = arr1 <= arr2
greater_than = arr1 > arr2
greater_than_or_equal_to = arr1 >= arr2

print("Equal To:", equal_to)
print("Not Equal To:", not_equal_to)
print("Less Than:", less_than)
print("Less Than or Equal To:", less_than_or_equal_to)
print("Greater Than:", greater_than)
print("Greater Than or Equal To:", greater_than_or_equal_to)

```

    Equal To: [False  True False  True  True]
    Not Equal To: [ True False  True False False]
    Less Than: [ True False False False False]
    Less Than or Equal To: [ True  True False  True  True]
    Greater Than: [False False  True False False]
    Greater Than or Equal To: [False  True  True  True  True]
    

### 51) How do you access a specific subarray or slice from a Numpy array?



```python
import numpy as np

# Create a NumPy array
arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])

# Slice from index 2 to 6 (exclusive)
subarray = arr[2:6]

print(subarray)

```

    [3 4 5 6]
    

### 52) Illustrate array indexing and slicing in multi-dimensional Numpy arrays with some examples.



```python
import numpy as np

# Create a 2D NumPy array
matrix = np.array([[10, 20, 30],
                  [40, 50, 60],
                  [70, 80, 90]])

# Print an element at a specific position
element = matrix[1, 2]  # Row 1 (second row), Column 2 (third column)

print("Element at (1, 2):", element)

```

    Element at (1, 2): 60
    

### 53) How do you create a Numpy array with a given shape containing all zeros?



```python
np.zeros((5,8))
```




    array([[0., 0., 0., 0., 0., 0., 0., 0.],
           [0., 0., 0., 0., 0., 0., 0., 0.],
           [0., 0., 0., 0., 0., 0., 0., 0.],
           [0., 0., 0., 0., 0., 0., 0., 0.],
           [0., 0., 0., 0., 0., 0., 0., 0.]])



### 54) How do you create a Numpy array with a given shape containing all ones?



```python
np.ones((2,4))

```




    array([[1., 1., 1., 1.],
           [1., 1., 1., 1.]])



### 55) How do you create an identity matrix of a given shape?



```python
import numpy as np

# Create a 3x3 identity matrix
identity_matrix = np.eye(3)

print(identity_matrix)

```

    [[1. 0. 0.]
     [0. 1. 0.]
     [0. 0. 1.]]
    

### 56) How do you create a random vector of a given length?


```python
import numpy as np

# Specify the length of the random vector
vector_length = 5

# Create a random vector of the specified length
random_vector = np.random.rand(vector_length)

print(random_vector)

```

    [0.18959182 0.80559481 0.00342392 0.02568944 0.56485023]
    

### 57) How do you create a Numpy array with a given shape with a fixed value for each element?



```python
import numpy as np

b1 = np.zeros(6)
print(b1)
```

    [0. 0. 0. 0. 0. 0.]
    

### 58) How do you create a Numpy array with a given shape containing randomly initialized elements?



```python
import numpy as np

# Specify the desired shape of the array
array_shape = (3, 4)  # Example: 3 rows and 4 columns

# Create a NumPy array with random values in the specified shape
random_array = np.random.rand(*array_shape)

print(random_array)

```

    [[0.86828801 0.72418823 0.53461011 0.69123282]
     [0.1953509  0.78071953 0.30684918 0.47195738]
     [0.97369305 0.64475261 0.19247895 0.68696269]]
    

### 59) What is the difference between np.random.rand and np.random.randn? Illustrate with examples.
### numpy.random.randn generates samples from the normal distribution, while numpy.random.rand from uniform (in range [0,1)).


```python
import numpy as np
import matplotlib.pyplot as plt

sample_size = 200000
uniform = np.random.rand(sample_size)
normal = np.random.randn(sample_size)

pdf, bins, patches = plt.hist(uniform, bins=20, range=(0, 1), density=True)
plt.title('rand: uniform')
plt.show()

pdf, bins, patches = plt.hist(normal, bins=20, range=(-4, 4), density=True)
plt.title('randn: normal')
plt.show()
```


    
![png](output_105_0.png)
    



    
![png](output_105_1.png)
    


### 60) What is the difference between np.arange and np.linspace? Illustrate with examples.
#### np.arange : Return evenly spaced values within a given interval.
#### np.linspace : Return evenly spaced numbers over a specified interval.



```python
np.linspace(0,2,9)
np.array([0. , 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1. ])
```




    array([0. , 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1. ])




```python
np.arange(0,1,.9)
np.array([0. , 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8])
```




    array([0. , 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8])



### 1. Import the numpy package under the name np


```python
import numpy as np
```

### 2. Print the numpy version and the configuration


```python
import numpy as np
print(np.__version__)
print(np.show_config())
```

    1.24.3
    blas_armpl_info:
      NOT AVAILABLE
    blas_mkl_info:
        libraries = ['mkl_rt']
        library_dirs = ['C:/Users/furqan ahmed/New folder\\Library\\lib']
        define_macros = [('SCIPY_MKL_H', None), ('HAVE_CBLAS', None)]
        include_dirs = ['C:/Users/furqan ahmed/New folder\\Library\\include']
    blas_opt_info:
        libraries = ['mkl_rt']
        library_dirs = ['C:/Users/furqan ahmed/New folder\\Library\\lib']
        define_macros = [('SCIPY_MKL_H', None), ('HAVE_CBLAS', None)]
        include_dirs = ['C:/Users/furqan ahmed/New folder\\Library\\include']
    lapack_armpl_info:
      NOT AVAILABLE
    lapack_mkl_info:
        libraries = ['mkl_rt']
        library_dirs = ['C:/Users/furqan ahmed/New folder\\Library\\lib']
        define_macros = [('SCIPY_MKL_H', None), ('HAVE_CBLAS', None)]
        include_dirs = ['C:/Users/furqan ahmed/New folder\\Library\\include']
    lapack_opt_info:
        libraries = ['mkl_rt']
        library_dirs = ['C:/Users/furqan ahmed/New folder\\Library\\lib']
        define_macros = [('SCIPY_MKL_H', None), ('HAVE_CBLAS', None)]
        include_dirs = ['C:/Users/furqan ahmed/New folder\\Library\\include']
    Supported SIMD extensions in this NumPy install:
        baseline = SSE,SSE2,SSE3
        found = SSSE3,SSE41,POPCNT,SSE42,AVX,F16C,FMA3,AVX2
        not found = AVX512F,AVX512CD,AVX512_SKX,AVX512_CLX,AVX512_CNL,AVX512_ICL
    None
    

### 3. Create a null vector of size 10


```python
import numpy as np
x = np.zeros(10)
print(x)
```

    [0. 0. 0. 0. 0. 0. 0. 0. 0. 0.]
    

### 4. How to find the memory size of any array


```python
import numpy as np

# Create a NumPy array
arr = np.array([1, 2, 3, 4, 5])

# Get the memory size of the array in bytes
memory_size = arr.itemsize * arr.size

print("Memory size of the array (in bytes):", memory_size)



```

    Memory size of the array (in bytes): 20
    

### 5. How to get the documentation of the numpy add function from the command line?


```python
import numpy as np
print(np.info(np.add))
```

    add(x1, x2, /, out=None, *, where=True, casting='same_kind', order='K', dtype=None, subok=True[, signature, extobj])
    
    Add arguments element-wise.
    
    Parameters
    ----------
    x1, x2 : array_like
        The arrays to be added.
        If ``x1.shape != x2.shape``, they must be broadcastable to a common
        shape (which becomes the shape of the output).
    out : ndarray, None, or tuple of ndarray and None, optional
        A location into which the result is stored. If provided, it must have
        a shape that the inputs broadcast to. If not provided or None,
        a freshly-allocated array is returned. A tuple (possible only as a
        keyword argument) must have length equal to the number of outputs.
    where : array_like, optional
        This condition is broadcast over the input. At locations where the
        condition is True, the `out` array will be set to the ufunc result.
        Elsewhere, the `out` array will retain its original value.
        Note that if an uninitialized `out` array is created via the default
        ``out=None``, locations within it where the condition is False will
        remain uninitialized.
    **kwargs
        For other keyword-only arguments, see the
        :ref:`ufunc docs <ufuncs.kwargs>`.
    
    Returns
    -------
    add : ndarray or scalar
        The sum of `x1` and `x2`, element-wise.
        This is a scalar if both `x1` and `x2` are scalars.
    
    Notes
    -----
    Equivalent to `x1` + `x2` in terms of array broadcasting.
    
    Examples
    --------
    >>> np.add(1.0, 4.0)
    5.0
    >>> x1 = np.arange(9.0).reshape((3, 3))
    >>> x2 = np.arange(3.0)
    >>> np.add(x1, x2)
    array([[  0.,   2.,   4.],
           [  3.,   5.,   7.],
           [  6.,   8.,  10.]])
    
    The ``+`` operator can be used as a shorthand for ``np.add`` on ndarrays.
    
    >>> x1 = np.arange(9.0).reshape((3, 3))
    >>> x2 = np.arange(3.0)
    >>> x1 + x2
    array([[ 0.,  2.,  4.],
           [ 3.,  5.,  7.],
           [ 6.,  8., 10.]])
    None
    

### 6. Create a null vector of size 10 but the fifth value which is 1


```python
x=np.zeros(10)
x[4]=1
print(x)
```

    [0. 0. 0. 0. 1. 0. 0. 0. 0. 0.]
    

### 7. Create a vector with values ranging from 10 to 49


```python
import numpy as np
v = np.arange(10,49)
print("Original vector:")
print(v)

```

    Original vector:
    [10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33
     34 35 36 37 38 39 40 41 42 43 44 45 46 47 48]
    

### 8. Reverse a vector (first element becomes last)



```python
import numpy as np

# Create a NumPy array (vector)
vector = np.array([1, 2, 3, 4, 5])

# Reverse the vector using slicing
reversed_vector = vector[::-1]

print("Original Vector:", vector)
print("Reversed Vector:", reversed_vector)

```

    Original Vector: [1 2 3 4 5]
    Reversed Vector: [5 4 3 2 1]
    

### 9. Create a 3x3 matrix with values ranging from 0 to 8



```python
import numpy as np
x =  np.arange(0, 9).reshape(3,3)
print(x)
```

    [[0 1 2]
     [3 4 5]
     [6 7 8]]
    

### 10. Find indices of non-zero elements from [1,2,0,0,4,0]



```python
arr = np.array([1,2,0,0,4,0])
print(arr[0])
print(arr[1])
print(arr[4])
```

    1
    2
    4
    

### 11. Create a 3x3 identity matrix (★☆☆)


```python
import numpy as np

# Create a 3x3 identity matrix
identity_matrix = np.identity(3)

print(identity_matrix)

```

    [[1. 0. 0.]
     [0. 1. 0.]
     [0. 0. 1.]]
    

### 12. Create a 3x3x3 array with random values (★☆☆)


```python
import numpy as np

# Create a 3x3x3 array with random values
random_array = np.random.rand(3, 3, 3)

print(random_array)

```

    [[[0.30556661 0.75977615 0.25964209]
      [0.11823807 0.85011116 0.44499123]
      [0.30654907 0.72221715 0.83832647]]
    
     [[0.64667859 0.43691789 0.61639746]
      [0.52530873 0.90334307 0.2919225 ]
      [0.83341666 0.29769163 0.07646971]]
    
     [[0.25904326 0.82036478 0.902011  ]
      [0.18784927 0.02565753 0.56353277]
      [0.61724199 0.70738236 0.64608341]]]
    

### 13. Create a 10x10 array with random values and find the minimum and maximum values (★☆☆)


```python
import numpy as np

# Create a 10x10 array with random values between 0 and 1
random_array = np.random.rand(10, 10)

# Find the minimum and maximum values in the array
min_value = np.min(random_array)
max_value = np.max(random_array)

print("Random Array:")
print(random_array)
print("\nMinimum Value:", min_value)
print("Maximum Value:", max_value)

```

    Random Array:
    [[1.06544297e-01 9.51629813e-01 6.60671869e-01 2.90936501e-01
      4.91613169e-01 9.63012466e-01 9.91054527e-01 7.72241851e-02
      9.34623505e-01 5.96082375e-01]
     [4.66999865e-02 7.60516110e-01 7.03999934e-01 1.21453713e-01
      9.04950127e-01 8.09519413e-01 4.23127851e-01 7.56027213e-01
      2.58733538e-02 1.05586474e-01]
     [2.14943189e-01 8.20517119e-01 3.63589337e-01 9.09738919e-01
      3.83923220e-01 1.26210161e-01 5.35493764e-01 1.78483290e-01
      2.01931743e-01 3.86529765e-01]
     [9.41991879e-01 3.45214257e-01 3.99755774e-01 6.43863697e-01
      9.66346535e-01 7.22503460e-01 2.74656910e-01 9.86938544e-01
      8.87074964e-01 9.22200265e-01]
     [9.70392639e-01 9.81598551e-01 7.50983804e-01 8.67624835e-01
      2.05804784e-01 1.58707061e-01 9.76644546e-01 3.04613828e-01
      7.99847579e-01 2.24439597e-01]
     [3.94653263e-01 3.15917638e-01 8.21507502e-01 2.39582285e-01
      3.03725008e-01 7.30746726e-02 1.82036233e-01 3.86787289e-01
      3.83312976e-01 4.65717621e-01]
     [7.61413912e-01 5.79530861e-01 4.66979163e-01 1.75336476e-01
      6.13224102e-01 3.90198033e-01 7.47482292e-01 3.12740329e-01
      7.53725672e-01 6.48947497e-01]
     [8.14636637e-01 6.45274806e-02 9.49725792e-01 5.35408435e-01
      5.10629135e-01 9.30214867e-01 9.30541724e-01 3.72811723e-01
      1.34143168e-01 2.57662853e-01]
     [1.26019014e-01 2.73595410e-01 1.89193379e-01 6.34155631e-01
      3.23315284e-02 2.78044868e-01 2.10477940e-01 5.90586111e-01
      7.45951795e-01 4.09691749e-01]
     [4.76215158e-01 5.36673039e-01 1.24431352e-01 5.49031884e-01
      8.54583676e-01 9.64993491e-01 3.49986331e-02 1.99347678e-01
      4.00012713e-04 8.27807385e-01]]
    
    Minimum Value: 0.00040001271291556506
    Maximum Value: 0.9910545265200066
    

### 14. Create a random vector of size 30 and find the mean value (★☆☆)


```python
rv=np.random.random((30))
rv.mean()
```




    0.4776828949645775



### 15. Create a 2d array with 1 on the border and 0 inside (★☆☆)


```python
import numpy as np

# Define the shape of the 2D array
rows, cols = 5, 5  # Adjust the dimensions as needed

# Create a 2D array of zeros
array = np.zeros((rows, cols), dtype=int)

# Set the border elements to 1
array[0, :] = 1
array[-1, :] = 1
array[:, 0] = 1
array[:, -1] = 1

print(array)

```

    [[1 1 1 1 1]
     [1 0 0 0 1]
     [1 0 0 0 1]
     [1 0 0 0 1]
     [1 1 1 1 1]]
    

### 16. How to add a border (filled with 0's) around an existing array? (★☆☆)


```python
import numpy as np

# Create an existing array (e.g., a 3x3 array)
existing_array = np.array([[1, 2, 3],
                           [4, 5, 6],
                           [7, 8, 9]])

# Determine the desired size for the new array with the border
rows, cols = existing_array.shape
border_size = 1  # Adjust the size of the border as needed

# Create a new larger array filled with 0's
new_array = np.zeros((rows + 2 * border_size, cols + 2 * border_size), dtype=existing_array.dtype)

# Copy the existing array into the center of the new array
new_array[border_size:border_size+rows, border_size:border_size+cols] = existing_array

print(new_array)

```

    [[0 0 0 0 0]
     [0 1 2 3 0]
     [0 4 5 6 0]
     [0 7 8 9 0]
     [0 0 0 0 0]]
    

### 17. What is the result of the following expression? (★☆☆)


```python
print(0 * np.nan)
print(np.nan == np.nan)
print(np.inf > np.nan)
print(np.nan - np.nan)
print(0.3 == 3 * 0.1)
```

    nan
    False
    False
    nan
    False
    

### 18. Create a 5x5 matrix with values 1,2,3,4 just below the diagonal (★☆☆)



```python
mtrx=np.diag(np.arange(1,5),k=-1)
print(mtrx)
```

    [[0 0 0 0 0]
     [1 0 0 0 0]
     [0 2 0 0 0]
     [0 0 3 0 0]
     [0 0 0 4 0]]
    

### 19. Create a 8x8 matrix and fill it with a checkerboard pattern (★☆☆)


```python
import numpy as np

# Create an 8x8 matrix with a checkerboard pattern
checkerboard = np.zeros((8, 8), dtype=int)

# Set alternating rows and columns to 1
checkerboard[1::2, ::2] = 1  # Odd rows and even columns
checkerboard[::2, 1::2] = 1  # Even rows and odd columns

print(checkerboard)

```

    [[0 1 0 1 0 1 0 1]
     [1 0 1 0 1 0 1 0]
     [0 1 0 1 0 1 0 1]
     [1 0 1 0 1 0 1 0]
     [0 1 0 1 0 1 0 1]
     [1 0 1 0 1 0 1 0]
     [0 1 0 1 0 1 0 1]
     [1 0 1 0 1 0 1 0]]
    

### 20. Consider a (6,7,8) shape array, what is the index (x,y,z) of the 100th element?


```python
import numpy as np
print (np.unravel_index(100, (6,7,8)))
```

    (1, 5, 4)
    

### 21. Create a checkerboard 8x8 matrix using the tile function (★☆☆)



```python
import numpy as np

# Create a 2x2 checkerboard pattern
checkerboard_pattern = np.array([[0, 1],
                                 [1, 0]])

# Use the tile function to replicate the pattern into an 8x8 matrix
checkerboard = np.tile(checkerboard_pattern, (4, 4))

print(checkerboard)

```

    [[0 1 0 1 0 1 0 1]
     [1 0 1 0 1 0 1 0]
     [0 1 0 1 0 1 0 1]
     [1 0 1 0 1 0 1 0]
     [0 1 0 1 0 1 0 1]
     [1 0 1 0 1 0 1 0]
     [0 1 0 1 0 1 0 1]
     [1 0 1 0 1 0 1 0]]
    

### 22. Normalize a 5x5 random matrix (★☆☆)



```python
import numpy as np

# Create a 5x5 random matrix
random_matrix = np.random.rand(5, 5)

# Find the minimum and maximum values
min_value = random_matrix.min()
max_value = random_matrix.max()

# Normalize the matrix
normalized_matrix = (random_matrix - min_value) / (max_value - min_value)

print("Original Random Matrix:")
print(random_matrix)
print("\nNormalized Matrix:")
print(normalized_matrix)

```

    Original Random Matrix:
    [[0.39417703 0.47073877 0.34838943 0.25538331 0.81015062]
     [0.6796918  0.41261625 0.38507928 0.48692123 0.34655509]
     [0.19539405 0.73554611 0.80710721 0.91829684 0.96819833]
     [0.85059078 0.00314273 0.12556217 0.16108008 0.76391663]
     [0.45109025 0.55988711 0.35642874 0.43519719 0.70183811]]
    
    Normalized Matrix:
    [[0.40519354 0.48452757 0.35774799 0.26137414 0.83622943]
     [0.70104672 0.42430044 0.39576637 0.50129598 0.35584722]
     [0.19921268 0.7589235  0.83307581 0.94829159 1.        ]
     [0.87813391 0.         0.12685221 0.16365621 0.78832131]
     [0.46416758 0.57690394 0.3660784  0.44769903 0.72399494]]
    

### 23. Create a custom dtype that describes a color as four unsigned bytes (RGBA) (★☆☆)


```python
color = np.dtype([("r", np.ubyte,  (1,)),
                  ("g", np.ubyte,  (1,)),
                  ("b", np.ubyte,  (1,)),
                  ("a", np.ubyte,  (1,))])
```

### 24. Multiply a 5x3 matrix by a 3x2 matrix (real matrix product) (★☆☆)


```python
RMP = np.dot(np.ones((5,3)), np.ones((3,2)))
print(RMP)

# Alternative solution, in Python 3.5 and above
RMP = np.ones((5,3)) @ np.ones((3,2))
print(RMP)
```

    [[3. 3.]
     [3. 3.]
     [3. 3.]
     [3. 3.]
     [3. 3.]]
    [[3. 3.]
     [3. 3.]
     [3. 3.]
     [3. 3.]
     [3. 3.]]
    

### 25. Given a 1D array, negate all elements which are between 3 and 8, in place. (★☆☆)



```python
X = np.arange(11)
X[(3 < X) & (X <= 8)] *= -1
print(X)
```

    [ 0  1  2  3 -4 -5 -6 -7 -8  9 10]
    

### 26. What is the output of the following script? (★☆☆)


```python
print(sum(range(5),-1))
from numpy import *
print(sum(range(5),-1))
```

    9
    10
    

### 27. Consider an integer vector Z, which of these expressions are legal? (★☆☆)



```python
Z**Z
2 << Z >> 2
Z <- Z
1*Z
Z/1/1
Z<Z>Z
```


    ---------------------------------------------------------------------------

    NameError                                 Traceback (most recent call last)

    Cell In[80], line 1
    ----> 1 Z**Z
          2 2 << Z >> 2
          3 Z <- Z
    

    NameError: name 'Z' is not defined


### 28. What are the result of the following expressions?



```python
np.array(0) / np.array(0)
np.array(0) // np.array(0)
np.array([np.nan]).astype(int).astype(float)
```

    C:\Users\lenovo\AppData\Local\Temp\ipykernel_700\548293649.py:1: RuntimeWarning: invalid value encountered in divide
      np.array(0) / np.array(0)
    C:\Users\lenovo\AppData\Local\Temp\ipykernel_700\548293649.py:2: RuntimeWarning: divide by zero encountered in floor_divide
      np.array(0) // np.array(0)
    C:\Users\lenovo\AppData\Local\Temp\ipykernel_700\548293649.py:3: RuntimeWarning: invalid value encountered in cast
      np.array([np.nan]).astype(int).astype(float)
    




    array([-2.14748365e+09])



### 29. How to round away from zero a float array ? (★☆☆)



```python
import numpy as np

# Create a float array
float_array = np.array([-1.5, 2.7, -3.4, 4.9, -5.2])

# Round away from zero using numpy.ceil() for positive numbers and numpy.floor() for negative numbers
rounded_array = np.where(float_array >= 0, np.ceil(float_array), np.floor(float_array))

print("Original Float Array:")
print(float_array)
print("\nRounded Array (Away from Zero):")
print(rounded_array)

```

    Original Float Array:
    [-1.5  2.7 -3.4  4.9 -5.2]
    
    Rounded Array (Away from Zero):
    [-2.  3. -4.  5. -6.]
    

### 30. How to find common values between two arrays? (★☆☆)



```python
X1 = np.random.randint(0,11,10)
X2 = np.random.randint(0,11,10)
print(np.intersect1d(X1,X2))
```

    [0 2 4 5]
    

### 31. How to ignore all numpy warnings (not recommended)? (★☆☆)


```python
with np.errstate(divide='ignore'):
    Z = np.ones(1) / 0
```

### 32. Is the following expressions true? (★☆☆)


```python
np.sqrt(-1) == np.emath.sqrt(-1)
```

    C:\Users\lenovo\AppData\Local\Temp\ipykernel_700\244602691.py:1: RuntimeWarning: invalid value encountered in sqrt
      np.sqrt(-1) == np.emath.sqrt(-1)
    




    False



### 33. How to get the dates of yesterday, today and tomorrow? (★☆☆)


```python
import numpy as np
from datetime import datetime, timedelta

# Get the current date (today)
today = datetime.now().date()

# Calculate the dates of yesterday and tomorrow
yesterday = today - timedelta(days=1)
tomorrow = today + timedelta(days=1)

# Create NumPy datetime64 objects
today_np = np.datetime64(today)
yesterday_np = np.datetime64(yesterday)
tomorrow_np = np.datetime64(tomorrow)

print("Yesterday:", yesterday_np)
print("Today:", today_np)
print("Tomorrow:", tomorrow_np)

```

    Yesterday: 2023-11-05
    Today: 2023-11-06
    Tomorrow: 2023-11-07
    

### 34. How to get all the dates corresponding to the month of July 2016? (★★☆)



```python
import numpy as np
from datetime import datetime, timedelta

# Define the start date for July 2016
start_date = datetime(2016, 7, 1)

# Define the end date for July 2016
end_date = datetime(2016, 7, 31)

# Create an empty NumPy array to store the dates
dates_in_july_2016 = np.array([])

# Generate all the dates in July 2016
current_date = start_date
while current_date <= end_date:
    dates_in_july_2016 = np.append(dates_in_july_2016, current_date)
    current_date += timedelta(days=1)

# Convert the NumPy array to datetime64 data type
dates_in_july_2016 = np.array(dates_in_july_2016, dtype='datetime64')

# Print the array of dates
print(dates_in_july_2016)



```

    ['2016-07-01T00:00:00.000000' '2016-07-02T00:00:00.000000'
     '2016-07-03T00:00:00.000000' '2016-07-04T00:00:00.000000'
     '2016-07-05T00:00:00.000000' '2016-07-06T00:00:00.000000'
     '2016-07-07T00:00:00.000000' '2016-07-08T00:00:00.000000'
     '2016-07-09T00:00:00.000000' '2016-07-10T00:00:00.000000'
     '2016-07-11T00:00:00.000000' '2016-07-12T00:00:00.000000'
     '2016-07-13T00:00:00.000000' '2016-07-14T00:00:00.000000'
     '2016-07-15T00:00:00.000000' '2016-07-16T00:00:00.000000'
     '2016-07-17T00:00:00.000000' '2016-07-18T00:00:00.000000'
     '2016-07-19T00:00:00.000000' '2016-07-20T00:00:00.000000'
     '2016-07-21T00:00:00.000000' '2016-07-22T00:00:00.000000'
     '2016-07-23T00:00:00.000000' '2016-07-24T00:00:00.000000'
     '2016-07-25T00:00:00.000000' '2016-07-26T00:00:00.000000'
     '2016-07-27T00:00:00.000000' '2016-07-28T00:00:00.000000'
     '2016-07-29T00:00:00.000000' '2016-07-30T00:00:00.000000'
     '2016-07-31T00:00:00.000000']
    

### 35. How to compute ((A+B)*(-A/2)) in place (without copy)? (★★☆)



```python
A = np.ones(3)*1
B = np.ones(3)*2
C = np.ones(3)*3
np.add(A,B,out=B)
np.divide(A,2,out=A)
np.negative(A,out=A)
np.multiply(A,B,out=A)
```




    array([-1.5, -1.5, -1.5])



### 36. Extract the integer part of a random array of positive numbers using 4 different methods (★★☆)



```python
import numpy as np

# Create a random array of positive numbers
random_array = np.random.rand(5) * 100  # Generating random numbers between 0 and 100

# Method 1: Using numpy.floor()
integer_part_floor = np.floor(random_array).astype(int)

# Method 2: Using numpy.trunc()
integer_part_trunc = np.trunc(random_array).astype(int)

# Method 3: Using integer casting
integer_part_casting = random_array.astype(int)

# Method 4: Using numpy.floor_divide()
integer_part_floor_divide = np.floor_divide(random_array, 1).astype(int)

print("Original Random Array:")
print(random_array)
print("\nMethod 1 (numpy.floor()):", integer_part_floor)
print("Method 2 (numpy.trunc()):", integer_part_trunc)
print("Method 3 (integer casting):", integer_part_casting)
print("Method 4 (numpy.floor_divide()):", integer_part_floor_divide)

```

    Original Random Array:
    [54.99044669 78.64605251 45.6478583  65.38409813 79.45743576]
    
    Method 1 (numpy.floor()): [54 78 45 65 79]
    Method 2 (numpy.trunc()): [54 78 45 65 79]
    Method 3 (integer casting): [54 78 45 65 79]
    Method 4 (numpy.floor_divide()): [54 78 45 65 79]
    

### 37. Create a 5x5 matrix with row values ranging from 0 to 4 (★★☆)



```python
import numpy as np

# Create a 5x5 matrix with row values ranging from 0 to 4
matrix = np.tile(np.arange(5), (5, 1))

print(matrix)

```

    [[0 1 2 3 4]
     [0 1 2 3 4]
     [0 1 2 3 4]
     [0 1 2 3 4]
     [0 1 2 3 4]]
    

### 38. Consider a generator function that generates 10 integers and use it to build an array (★☆☆)



```python
import numpy as np

# Define a generator function that yields 10 integers
def integer_generator():
    for i in range(10):
        yield i

# Use the generator to build a NumPy array
integer_array = np.fromiter(integer_generator(), dtype=int)

print(integer_array)

```

    [0 1 2 3 4 5 6 7 8 9]
    

### 39. Create a vector of size 10 with values ranging from 0 to 1, both excluded (★★☆)



```python
import numpy as np

# Create a vector of size 10 with values ranging from 0 to 1 (both excluded)
vector = np.linspace(0, 1, 12)[1:-1]

print(vector)

```

    [0.09090909 0.18181818 0.27272727 0.36363636 0.45454545 0.54545455
     0.63636364 0.72727273 0.81818182 0.90909091]
    

### 40. Create a random vector of size 10 and sort it (★★☆)


```python
RV = np.random.random(10)
RV.sort()
print(RV)
```

    [0.02395422 0.21746973 0.41827471 0.54729663 0.61581037 0.82116986
     0.8337472  0.85126003 0.91293882 0.96530661]
    

### 41. How to sum a small array faster than np.sum? (★★☆)



```python
SA = np.arange(9)
np.add.reduce(SA)
```




    36



### 42. Consider two random array A and B, check if they are equal (★★☆)



```python
import numpy as np

# Create two random arrays A and B
A = np.random.rand(5)
B = np.random.rand(5)

# Check if A and B are equal using numpy.array_equal()
are_equal = np.array_equal(A, B)

if are_equal:
    print("Arrays A and B are equal.")
else:
    print("Arrays A and B are not equal.")

```

    Arrays A and B are not equal.
    

### 43. Make an array immutable (read-only) (★★☆)



```python
Z = np.zeros(10)
Z.flags.writeable = False
Z[0] = 1
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[98], line 3
          1 Z = np.zeros(10)
          2 Z.flags.writeable = False
    ----> 3 Z[0] = 1
    

    ValueError: assignment destination is read-only


### 44. Consider a random 10x2 matrix representing cartesian coordinates, convert them to polar coordinates (★★☆)



```python
import numpy as np

# Create a random 10x2 matrix of cartesian coordinates
cartesian_coordinates = np.random.rand(10, 2)

# Split the cartesian coordinates into x and y columns
x, y = cartesian_coordinates[:, 0], cartesian_coordinates[:, 1]

# Calculate the radial distance (r) using the Pythagorean theorem
r = np.sqrt(x**2 + y**2)

# Calculate the polar angle (theta) using arctan2
theta = np.arctan2(y, x)

# Convert radians to degrees if needed
# theta_degrees = np.degrees(theta)

# Create a 10x2 matrix of polar coordinates
polar_coordinates = np.column_stack((r, theta))

print("Cartesian Coordinates:")
print(cartesian_coordinates)
print("\nPolar Coordinates (r, theta):")
print(polar_coordinates)

```

    Cartesian Coordinates:
    [[0.21128625 0.64332111]
     [0.98313861 0.07521641]
     [0.96582191 0.1891097 ]
     [0.46287377 0.66919394]
     [0.94708332 0.35635992]
     [0.874112   0.23118059]
     [0.08392442 0.88251987]
     [0.55084465 0.09484154]
     [0.89601894 0.43707288]
     [0.70579894 0.99613523]]
    
    Polar Coordinates (r, theta):
    [[0.67712919 1.25346483]
     [0.98601168 0.07635766]
     [0.9841618  0.19335562]
     [0.81367848 0.96567034]
     [1.01190869 0.35988444]
     [0.90416606 0.25855492]
     [0.88650134 1.4759851 ]
     [0.55894968 0.17050306]
     [0.99693663 0.45383541]
     [1.22083477 0.9543636 ]]
    

### 45. Create random vector of size 10 and replace the maximum value by 0 (★★☆)


```python
RV = np.random.random(10)
RV[RV.argmax()] = 0
print(RV)
```

    [0.19385318 0.82451652 0.07088663 0.08686148 0.5251191  0.00183669
     0.30468832 0.         0.54708488 0.47727643]
    

### 46. Create a structured array with x and y coordinates covering the [0,1]x[0,1] area (★★☆)


```python
import numpy as np

# Define the size of the grid
grid_size = 5  # You can adjust the size as needed

# Create a grid of x and y coordinates covering the [0, 1] x [0, 1] area
x = np.linspace(0, 1, grid_size)
y = np.linspace(0, 1, grid_size)

x, y = np.meshgrid(x, y)

# Create a structured array
structured_array = np.empty((grid_size, grid_size), dtype=[('x', float), ('y', float)])
structured_array['x'] = x
structured_array['y'] = y

print(structured_array)

```

    [[(0.  , 0.  ) (0.25, 0.  ) (0.5 , 0.  ) (0.75, 0.  ) (1.  , 0.  )]
     [(0.  , 0.25) (0.25, 0.25) (0.5 , 0.25) (0.75, 0.25) (1.  , 0.25)]
     [(0.  , 0.5 ) (0.25, 0.5 ) (0.5 , 0.5 ) (0.75, 0.5 ) (1.  , 0.5 )]
     [(0.  , 0.75) (0.25, 0.75) (0.5 , 0.75) (0.75, 0.75) (1.  , 0.75)]
     [(0.  , 1.  ) (0.25, 1.  ) (0.5 , 1.  ) (0.75, 1.  ) (1.  , 1.  )]]
    

### 47. Given two arrays, X and Y, construct the Cauchy matrix C (Cij =1/(xi - yj))



```python
import numpy as np

# Define the arrays X and Y
X = np.array([1, 2, 3, 4])
Y = np.array([0.5, 1.5, 2.5])

# Initialize the Cauchy matrix with zeros
C = np.zeros((len(X), len(Y)))

# Calculate the values for the Cauchy matrix
for i in range(len(X)):
    for j in range(len(Y)):
        C[i, j] = 1 / (X[i] - Y[j])

print("Cauchy Matrix C:")
print(C)


```

    Cauchy Matrix C:
    [[ 2.         -2.         -0.66666667]
     [ 0.66666667  2.         -2.        ]
     [ 0.4         0.66666667  2.        ]
     [ 0.28571429  0.4         0.66666667]]
    

### 48. Print the minimum and maximum representable value for each numpy scalar type (★★☆)


```python
import numpy as np

# Integer scalar types
integer_scalar_types = [np.int8, np.uint8, np.int16, np.uint16, np.int32, np.uint32, np.int64, np.uint64]

print("Minimum and Maximum representable values for Integer Scalar Types:")
for dtype in integer_scalar_types:
    info = np.iinfo(dtype)
    print(f"{dtype.__name__}:")
    print(f"  Minimum: {info.min}")
    print(f"  Maximum: {info.max}")

# Floating-point scalar types
float_scalar_types = [np.float16, np.float32, np.float64]

print("\nMinimum and Maximum representable values for Floating-point Scalar Types:")
for dtype in float_scalar_types:
    info = np.finfo(dtype)
    print(f"{dtype.__name__}:")
    print(f"  Minimum: {info.min}")
    print(f"  Maximum: {info.max}")

```

    Minimum and Maximum representable values for Integer Scalar Types:
    int8:
      Minimum: -128
      Maximum: 127
    uint8:
      Minimum: 0
      Maximum: 255
    int16:
      Minimum: -32768
      Maximum: 32767
    uint16:
      Minimum: 0
      Maximum: 65535
    int32:
      Minimum: -2147483648
      Maximum: 2147483647
    uint32:
      Minimum: 0
      Maximum: 4294967295
    int64:
      Minimum: -9223372036854775808
      Maximum: 9223372036854775807
    uint64:
      Minimum: 0
      Maximum: 18446744073709551615
    
    Minimum and Maximum representable values for Floating-point Scalar Types:
    float16:
      Minimum: -65504.0
      Maximum: 65504.0
    float32:
      Minimum: -3.4028234663852886e+38
      Maximum: 3.4028234663852886e+38
    float64:
      Minimum: -1.7976931348623157e+308
      Maximum: 1.7976931348623157e+308
    

### 49. How to print all the values of an array? (★★☆)



```python
import numpy as np

# Create a NumPy array
array = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])

# Print all the values in the array
for value in array:
    print(value)

```

    1
    2
    3
    4
    5
    6
    7
    8
    9
    

### 50. How to find the closest value (to a given scalar) in a vector? (★★☆)


```python
import numpy as np

# Create a NumPy array
vector = np.array([3, 7, 1, 10, 5, 8])

# Scalar value to find the closest value to
scalar = 6

# Find the index of the closest value in the vector
closest_index = np.argmin(np.abs(vector - scalar))

# Get the closest value itself
closest_value = vector[closest_index]

print("Vector:", vector)
print("Scalar:", scalar)
print("Closest Value:", closest_value)

```

    Vector: [ 3  7  1 10  5  8]
    Scalar: 6
    Closest Value: 7
    

### 51. Create a structured array representing a position (x,y) and a color (r,g,b) (★★☆)


```python
SA = np.zeros(10, [ ('position', [ ('x', float, 1),
                                  ('y', float, 1)]),
                   ('color',    [ ('r', float, 1),
                                  ('g', float, 1),
                                  ('b', float, 1)])])
print(SA)
```

    [((0., 0.), (0., 0., 0.)) ((0., 0.), (0., 0., 0.))
     ((0., 0.), (0., 0., 0.)) ((0., 0.), (0., 0., 0.))
     ((0., 0.), (0., 0., 0.)) ((0., 0.), (0., 0., 0.))
     ((0., 0.), (0., 0., 0.)) ((0., 0.), (0., 0., 0.))
     ((0., 0.), (0., 0., 0.)) ((0., 0.), (0., 0., 0.))]
    

    C:\Users\lenovo\AppData\Local\Temp\ipykernel_700\941262719.py:1: FutureWarning: Passing (type, 1) or '1type' as a synonym of type is deprecated; in a future version of numpy, it will be understood as (type, (1,)) / '(1,)type'.
      SA = np.zeros(10, [ ('position', [ ('x', float, 1),
    

### 52. Consider a random vector with shape (100,2) representing coordinates, find point by point distances (★★☆)



```python
import numpy as np

# Create a random vector with shape (100, 2) representing coordinates
coordinates = np.random.rand(100, 2)

# Calculate point-by-point distances
distances = np.linalg.norm(coordinates[:, np.newaxis] - coordinates, axis=2)

print("Point-by-Point Distances:")
print(distances)

```

    Point-by-Point Distances:
    [[0.         0.65437902 0.38558064 ... 0.62749316 0.65153507 0.36975385]
     [0.65437902 0.         0.44047765 ... 1.07323884 0.12705904 0.97146088]
     [0.38558064 0.44047765 0.         ... 0.98922945 0.51240364 0.75519949]
     ...
     [0.62749316 1.07323884 0.98922945 ... 0.         0.99774567 0.34657253]
     [0.65153507 0.12705904 0.51240364 ... 0.99774567 0.         0.93444455]
     [0.36975385 0.97146088 0.75519949 ... 0.34657253 0.93444455 0.        ]]
    

### 53. How to convert a float (32 bits) array into an integer (32 bits) in place?



```python
import numpy as np

# Create a float32 array
float_array = np.array([1.23, 4.56, 7.89], dtype=np.float32)

# Convert the float32 array to int32 in place
int_array = float_array.view(np.int32)

# Modify the integer array (if needed)
int_array[0] = 42  # Example: Modify the first element of the integer array

# Check the original float array and the modified integer array
print("Original Float Array (float32):", float_array)
print("Modified Integer Array (int32):", int_array)


```

    Original Float Array (float32): [5.89e-44 4.56e+00 7.89e+00]
    Modified Integer Array (int32): [        42 1083304837 1090288353]
    

### 54. How to read the following file? (★★☆)


```python
from io import StringIO

s = StringIO("""1, 2, 3, 4, 5\n
                6,  ,  , 7, 8\n
                 ,  , 9,10,11\n""")
Z = np.genfromtxt(s, delimiter=",", dtype=np.int32)
print(Z)
```

    [[ 1  2  3  4  5]
     [ 6 -1 -1  7  8]
     [-1 -1  9 10 11]]
    

### 55. What is the equivalent of enumerate for numpy arrays? (★★☆)



```python
import numpy as np

# Create a NumPy array
arr = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])

# Enumerate over the elements of the NumPy array along with their indices
for index, value in np.ndenumerate(arr):
    print(f"Index: {index}, Value: {value}")

```

    Index: (0, 0), Value: 1
    Index: (0, 1), Value: 2
    Index: (0, 2), Value: 3
    Index: (1, 0), Value: 4
    Index: (1, 1), Value: 5
    Index: (1, 2), Value: 6
    Index: (2, 0), Value: 7
    Index: (2, 1), Value: 8
    Index: (2, 2), Value: 9
    

### 56. Generate a generic 2D Gaussian-like array (★★☆)



```python
import numpy as np

size = 5
x, y = np.meshgrid(np.linspace(0, size - 1, size), np.linspace(0, size - 1, size))
mean = (size - 1) / 2
sigma = 1.0
gaussian_array = np.exp(-((x - mean)**2 + (y - mean)**2) / (2 * sigma**2))

print(gaussian_array)


```

    [[0.01831564 0.082085   0.13533528 0.082085   0.01831564]
     [0.082085   0.36787944 0.60653066 0.36787944 0.082085  ]
     [0.13533528 0.60653066 1.         0.60653066 0.13533528]
     [0.082085   0.36787944 0.60653066 0.36787944 0.082085  ]
     [0.01831564 0.082085   0.13533528 0.082085   0.01831564]]
    

### 57. How to randomly place p elements in a 2D array? (★★☆)



```python
import numpy as np

# Create a 2D array (e.g., a 5x5 array)
rows, cols = 5, 5
array = np.zeros((rows, cols))

# Number of elements to randomly place
p = 10

# Generate random row and column indices for placing elements
random_indices = np.random.choice(rows * cols, p, replace=False)
row_indices, col_indices = divmod(random_indices, cols)

# Place random values in the 2D array at the selected indices
for row, col in zip(row_indices, col_indices):
    array[row, col] = np.random.rand()  # Assign a random value

# Print the resulting 2D array
print(array)

```

    [[0.79624048 0.04510574 0.         0.79432629 0.        ]
     [0.42562549 0.         0.87784962 0.         0.        ]
     [0.45554157 0.21983505 0.61009701 0.         0.        ]
     [0.         0.         0.         0.         0.        ]
     [0.         0.         0.64682776 0.         0.40271781]]
    

### 58. Subtract the mean of each row of a matrix (★★☆)



```python
J = np.random.rand(5, 15)

# Recent versions of numpy
K = J - J.mean(axis=1, keepdims=True)

# Older versions of numpy
L = J - J.mean(axis=1).reshape(-1, 1)

print(K)
```

    [[-0.26189906  0.04715916  0.43759082  0.23137071 -0.35627315  0.31166225
      -0.40182557 -0.38561169 -0.31727403 -0.41493394  0.22899472  0.38780567
       0.00401632  0.2058405   0.28337728]
     [-0.49119347  0.31771795 -0.17489315  0.03075347  0.26849901 -0.19961669
       0.26653174  0.31311155  0.36667545  0.04784383  0.03651075 -0.49662894
       0.20962758 -0.23588526 -0.25905382]
     [ 0.4413026  -0.22416659  0.0786115   0.34079407 -0.24432822 -0.42124168
       0.02109876 -0.04836629 -0.42617286 -0.24287448  0.43480541  0.01205419
       0.32437815 -0.45548675  0.40959221]
     [ 0.52548881 -0.32012523  0.08481973 -0.38021217  0.15159958 -0.33805173
       0.50237982  0.01480534  0.00690312 -0.43615739  0.29543377 -0.03560809
      -0.24272014 -0.1951345   0.36657909]
     [ 0.1676155   0.27648403  0.00411645  0.13109876 -0.07275564 -0.08332884
       0.2075184  -0.42141634  0.20666228 -0.11951063 -0.4880736  -0.43538764
       0.06772508  0.35192439  0.2073278 ]]
    

### 59. How to sort an array by the nth column? (★★☆)


```python
nth = np.random.randint(0,10,(3,3))
print(nth)
print(nth[nth[:,1].argsort()])
```

    [[2 1 1]
     [6 9 8]
     [8 2 7]]
    [[2 1 1]
     [8 2 7]
     [6 9 8]]
    

### 60. How to tell if a given 2D array has null columns? (★★☆)



```python
A = np.random.randint(0,3,(3,10))
print((~A.any(axis=0)).any())
```

    False
    

### 61. Find the nearest value from a given value in an array (★★☆)



```python
Z = np.random.uniform(0,1,10)
z = 0.5
m = Z.flat[np.abs(Z - z).argmin()]
print(m)
```

    0.5243554939323393
    

### 62. Considering two arrays with shape (1,3) and (3,1), how to compute their sum using an iterator? (★★☆)


```python
import numpy as np

# Create two arrays with shape (1, 3) and (3, 1)
array1 = np.array([[1, 2, 3]])
array2 = np.array([[4], [5], [6]])

# Check if the arrays are compatible for element-wise addition
if array1.shape == (1, 3) and array2.shape == (3, 1):
    # Initialize the sum
    result = np.zeros((1, 1))

    # Create an iterator for array1
    it1 = np.nditer(array1)

    # Create an iterator for array2
    it2 = np.nditer(array2)

    # Iterate and add the elements
    while not it1.finished and not it2.finished:
        result += it1[0] + it2[0]
        it1.iternext()
        it2.iternext()

    print("Result of element-wise sum:", result[0, 0])
else:
    print("Array shapes are not compatible for element-wise addition.")

```

    Result of element-wise sum: 21.0
    

### 63. Create an array class that has a name attribute (★★☆)



```python
import numpy as np

class NamedArray(np.ndarray):
    def __new__(cls, input_array, name=None):
        obj = np.asarray(input_array).view(cls)
        obj.name = name
        return obj

# Create a NamedArray with a name
arr = NamedArray([1, 2, 3], name="MyArray")

# Access the name attribute
print("Name:", arr.name)

# Access the array elements
print("Array:", arr)

```

    Name: MyArray
    Array: [1 2 3]
    

### 64. Consider a given vector, how to add 1 to each element indexed by a second vector (be careful with repeated indices)? (★★★)



```python
import numpy as np

# Given vector
original_vector = np.array([1, 2, 3, 4, 5])

# Second vector representing indices to increment
indices_to_increment = np.array([1, 3, 3, 4, 4])

# Create a new vector with 1 added to the specified indices
result_vector = original_vector.copy()  # Copy the original vector to avoid modifying it in-place
unique_indices = np.unique(indices_to_increment)

# Iterate through the unique indices and increment the corresponding elements
for index in unique_indices:
    result_vector[index] += 1

print("Original Vector:", original_vector)
print("Indices to Increment:", indices_to_increment)
print("Result Vector:", result_vector)

```

    Original Vector: [1 2 3 4 5]
    Indices to Increment: [1 3 3 4 4]
    Result Vector: [1 3 3 5 6]
    

### 65. How to accumulate elements of a vector (X) to an array (F) based on an index list (I)? (★★★)



```python
import numpy as np

# Example vector X
X = np.array([1, 2, 3, 4, 5])

# Example index list I
I = np.array([1, 3, 0, 2, 4])

# Determine the size of the resulting array F
F_size = np.max(I) + 1

# Create an array F with zeros
F = np.zeros(F_size, dtype=X.dtype)

# Accumulate elements of X into F based on the index list I
for i in range(len(I)):
    F[I[i]] += X[i]

print("Vector X:", X)
print("Index List I:", I)
print("Accumulated Array F:", F)

```

    Vector X: [1 2 3 4 5]
    Index List I: [1 3 0 2 4]
    Accumulated Array F: [3 1 4 2 5]
    

### 66. Considering a (w,h,3) image of (dtype=ubyte), compute the number of unique colors (★★★)


```python
import numpy as np

# Create a sample image as a NumPy array with shape (w, h, 3) and dtype 'ubyte'
image = np.random.randint(0, 256, size=(10, 10, 3), dtype=np.uint8)

# Reshape the image to a (w*h, 3) 2D array
reshaped_image = image.reshape(-1, 3)

# Use numpy.unique to find unique colors
unique_colors = np.unique(reshaped_image, axis=0)

# Get the number of unique colors
num_unique_colors = unique_colors.shape[0]

print("Number of Unique Colors:", num_unique_colors)

```

    Number of Unique Colors: 100
    

### 67. Considering a four dimensions array, how to get sum over the last two axis at once? (★★★)


```python
import numpy as np

# Create a sample 4D array
# Replace this with your own 4D array
four_dimensional_array = np.random.rand(2, 3, 4, 5)

# Get the sum over the last two axes (axis 2 and axis 3)
sum_over_last_two_axes = np.sum(four_dimensional_array, axis=(-2, -1))

print("Original 4D Array:")
print(four_dimensional_array)
print("Sum Over Last Two Axes:")
print(sum_over_last_two_axes)

```

    Original 4D Array:
    [[[[0.01962913 0.74278021 0.80057673 0.74894469 0.61862317]
       [0.31332342 0.03358951 0.21205118 0.22529961 0.11886119]
       [0.21412773 0.06610724 0.90581621 0.39596996 0.54188922]
       [0.83235782 0.98689358 0.70387692 0.09662654 0.04038284]]
    
      [[0.263543   0.4933924  0.98591798 0.65229583 0.21162669]
       [0.91515405 0.31605275 0.77897335 0.54660997 0.88858624]
       [0.61809356 0.02178985 0.81922938 0.44829976 0.63873716]
       [0.85479249 0.29906734 0.78961605 0.53107193 0.30113011]]
    
      [[0.55560168 0.27280167 0.04749923 0.94575669 0.82381057]
       [0.44374743 0.50056439 0.41724372 0.73136736 0.53574093]
       [0.59767136 0.95362395 0.45766195 0.44022533 0.97764072]
       [0.78938095 0.83477172 0.69283991 0.15239029 0.66085833]]]
    
    
     [[[0.14279248 0.54104333 0.4686523  0.42741318 0.63188234]
       [0.15772162 0.54025742 0.51623636 0.23041463 0.07704408]
       [0.72462967 0.88380225 0.11830229 0.18826269 0.15396047]
       [0.6858657  0.8124354  0.72350876 0.52480784 0.69130742]]
    
      [[0.91781023 0.40029792 0.32812349 0.30409648 0.92196486]
       [0.42726267 0.09463813 0.65537573 0.47340862 0.17551602]
       [0.5152685  0.17297674 0.27647297 0.8147942  0.35822679]
       [0.45759107 0.94455829 0.86614299 0.62273246 0.71409645]]
    
      [[0.66409769 0.32031651 0.41812757 0.82727167 0.54109403]
       [0.76032799 0.84107067 0.34543653 0.89799012 0.27103843]
       [0.86932486 0.57191709 0.9576622  0.6242323  0.41077387]
       [0.02008911 0.96996304 0.67443599 0.2489331  0.10153674]]]]
    Sum Over Last Two Axes:
    [[ 8.61772689 11.37397986 11.83119817]
     [ 9.24034022 10.44135462 11.33563952]]
    

### 68. Considering a one-dimensional vector D, how to compute means of subsets of D using a vector S of same size describing subset indices? (★★★)



```python
import numpy as np

# Create a one-dimensional vector D and a corresponding vector S of subset indices
D = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
S = np.array([0, 1, 0, 1, 1, 0, 1, 0, 1])  # Subset indices (0 or 1)

# Get unique subset indices
unique_indices = np.unique(S)

# Compute the means of subsets
subset_means = [np.mean(D[S == idx]) for idx in unique_indices]

# Print the means of subsets
for idx, mean in zip(unique_indices, subset_means):
    print(f"Subset {idx} Mean: {mean}")

```

    Subset 0 Mean: 4.5
    Subset 1 Mean: 5.4
    

### 69. How to get the diagonal of a dot product? (★★★)



```python
import numpy as np

# Create two matrices A and B
A = np.array([[1, 2, 3],
              [4, 5, 6],
              [7, 8, 9]])

B = np.array([[9, 8, 7],
              [6, 5, 4],
              [3, 2, 1]])

# Compute the dot product of A and B
dot_product_result = np.dot(A, B)

# Get the diagonal of the dot product
diagonal_of_dot_product = np.diag(dot_product_result)

print("Matrix A:")
print(A)

print("Matrix B:")
print(B)

print("Dot Product of A and B:")
print(dot_product_result)

print("Diagonal of the Dot Product:")
print(diagonal_of_dot_product)

```

    Matrix A:
    [[1 2 3]
     [4 5 6]
     [7 8 9]]
    Matrix B:
    [[9 8 7]
     [6 5 4]
     [3 2 1]]
    Dot Product of A and B:
    [[ 30  24  18]
     [ 84  69  54]
     [138 114  90]]
    Diagonal of the Dot Product:
    [30 69 90]
    

### 70. Consider the vector [1, 2, 3, 4, 5], how to build a new vector with 3 consecutive zeros interleaved between each value? (★★★)


```python
import numpy as np

# Original vector
original_vector = np.array([1, 2, 3, 4, 5])

# Number of consecutive zeros to insert
zeros_to_insert = 3

# Build a new vector with interleaved zeros
new_vector = np.zeros(len(original_vector) + (len(original_vector) - 1) * zeros_to_insert, dtype=original_vector.dtype)

# Assign values and zeros in an interleaved manner
new_vector[::zeros_to_insert + 1] = original_vector

print("Original Vector:")
print(original_vector)

print("New Vector with Interleaved Zeros:")
print(new_vector)

```

    Original Vector:
    [1 2 3 4 5]
    New Vector with Interleaved Zeros:
    [1 0 0 0 2 0 0 0 3 0 0 0 4 0 0 0 5]
    

### 71. Consider an array of dimension (5,5,3), how to mulitply it by an array with dimensions (5,5)? (★★★)


```python
import numpy as np

# Create a 3D array with dimensions (5, 5, 3)
array_3d = np.random.rand(5, 5, 3)

# Create a 2D array with dimensions (5, 5)
array_2d = np.random.rand(5, 5)

# Multiply the 3D array by the 2D array using broadcasting
result = array_3d * array_2d[:, :, np.newaxis]

print("3D Array:")
print(array_3d)

print("2D Array:")
print(array_2d)

print("Result (3D Array * 2D Array):")
print(result)

```

    3D Array:
    [[[0.47489403 0.95953404 0.70382388]
      [0.59080875 0.80550647 0.47326497]
      [0.93661351 0.63630455 0.16220194]
      [0.44996059 0.96788039 0.52381685]
      [0.20715931 0.05256102 0.33049115]]
    
     [[0.86927651 0.15375602 0.65418747]
      [0.21789561 0.50388005 0.21011517]
      [0.79880937 0.08021047 0.84005963]
      [0.57058443 0.9156477  0.31490525]
      [0.43497123 0.44923631 0.19521093]]
    
     [[0.05268221 0.61024475 0.82755518]
      [0.71279105 0.35612962 0.55257776]
      [0.35938598 0.97626391 0.32180401]
      [0.94719455 0.08932142 0.59765758]
      [0.7851754  0.29961717 0.56027154]]
    
     [[0.98913149 0.39426567 0.14282404]
      [0.64386058 0.02664095 0.28931419]
      [0.58850437 0.16243314 0.88146197]
      [0.79178428 0.96140322 0.68840448]
      [0.84854842 0.01877346 0.57654597]]
    
     [[0.48637797 0.84618625 0.92330524]
      [0.00512117 0.706961   0.06201515]
      [0.13826741 0.40353527 0.84902973]
      [0.56430664 0.74835174 0.67099264]
      [0.91659612 0.6074523  0.613602  ]]]
    2D Array:
    [[0.97430427 0.74902082 0.49664499 0.0414701  0.29305969]
     [0.02173487 0.00456698 0.63832184 0.97760386 0.26473344]
     [0.79847582 0.39485074 0.26349919 0.14256426 0.65682047]
     [0.55567672 0.29821491 0.48314677 0.41018362 0.74212647]
     [0.04582227 0.11533909 0.75281481 0.54649474 0.68497989]]
    Result (3D Array * 2D Array):
    [[[4.62691284e-01 9.34878112e-01 6.85738611e-01]
      [4.42528052e-01 6.03341113e-01 3.54485315e-01]
      [4.65164407e-01 3.16017464e-01 8.05567794e-02]
      [1.86599111e-02 4.01380979e-02 2.17227378e-02]
      [6.07100426e-02 1.54035152e-02 9.68536323e-02]]
    
     [[1.88936129e-02 3.34186717e-03 1.42186803e-02]
      [9.95125403e-04 2.30121132e-03 9.59592263e-04]
      [5.09897467e-01 5.12000964e-02 5.36228413e-01]
      [5.57805542e-01 8.95140730e-01 3.07852592e-01]
      [1.15151430e-01 1.18927874e-01 5.16788603e-02]]
    
     [[4.20654671e-02 4.87265674e-01 6.60782798e-01]
      [2.81446076e-01 1.40618043e-01 2.18185736e-01]
      [9.46979147e-02 2.57244750e-01 8.47950970e-02]
      [1.35036089e-01 1.27340424e-02 8.52046103e-02]
      [5.15719280e-01 1.96794692e-01 3.67997820e-01]]
    
     [[5.49637339e-01 2.19084252e-01 7.93639944e-02]
      [1.92008825e-01 7.94472827e-03 8.62778051e-02]
      [2.84333987e-01 7.84790474e-02 4.25875509e-01]
      [3.24776944e-01 3.94351854e-01 2.82372244e-01]
      [6.29730239e-01 1.39322840e-02 4.27870027e-01]]
    
     [[2.22869446e-02 3.87741787e-02 4.23079463e-02]
      [5.90670785e-04 8.15402377e-02 7.15277132e-03]
      [1.04089757e-01 3.03787324e-01 6.39162158e-01]
      [3.08390611e-01 4.08970289e-01 3.66693945e-01]
      [6.27849913e-01 4.16092607e-01 4.20305034e-01]]]
    

### 72. How to swap two rows of an array? (★★★)



```python
import numpy as np

# Create a sample 2D array
array = np.array([[1, 2, 3],
                  [4, 5, 6],
                  [7, 8, 9]])

# Swap rows 1 and 2 (0-based indexing)
row1, row2 = 1, 2
array[row1], array[row2] = array[row2].copy(), array[row1].copy()

print("Original Array:")
print(array)

```

    Original Array:
    [[1 2 3]
     [7 8 9]
     [4 5 6]]
    

### 73. Consider a set of 10 triplets describing 10 triangles (with shared vertices), find the set of unique line segments composing all the triangles (★★★)


```python
# Sample set of 10 triplets describing triangles
triplets = [(1, 2, 3), (2, 3, 4), (3, 4, 5), (4, 5, 6),
            (5, 6, 7), (6, 7, 8), (7, 8, 9), (8, 9, 10),
            (9, 10, 1), (10, 1, 2)]

# Initialize a set to store unique line segments
unique_segments = set()

# Iterate through the triplets and extract line segments
for triplet in triplets:
    for i in range(3):
        segment = (triplet[i], triplet[(i + 1) % 3])
        unique_segments.add(segment)

# Convert the set of unique line segments to a list
unique_segments_list = list(unique_segments)

print("Unique Line Segments:")
for segment in unique_segments_list:
    print(segment)

```

    Unique Line Segments:
    (3, 4)
    (3, 1)
    (8, 9)
    (8, 6)
    (1, 9)
    (4, 2)
    (4, 5)
    (5, 6)
    (5, 3)
    (9, 7)
    (9, 10)
    (1, 2)
    (10, 8)
    (2, 10)
    (6, 4)
    (6, 7)
    (10, 1)
    (2, 3)
    (7, 5)
    (7, 8)
    

### 74. Given an array C that is a bincount, how to produce an array A such that np.bincount(A) == C? (★★★)


```python
import numpy as np

# Given bincount array C
C = np.array([0, 1, 2, 0, 1, 3, 2])

# Compute the array A
A = np.repeat(np.arange(len(C)), C)

print("Array A:", A)
print("Bincount of A:", np.bincount(A))

```

    Array A: [1 2 2 4 5 5 5 6 6]
    Bincount of A: [0 1 2 0 1 3 2]
    

### 75. How to compute averages using a sliding window over an array? (★★★)



```python
import numpy as np

# Sample array
arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])

# Define the window size for the sliding window
window_size = 3

# Compute averages using a sliding window
averages = np.convolve(arr, np.ones(window_size) / window_size, mode='valid')

print("Original Array:")
print(arr)
print(f"Averages with {window_size}-element sliding window:")
print(averages)

```

    Original Array:
    [1 2 3 4 5 6 7 8 9]
    Averages with 3-element sliding window:
    [2. 3. 4. 5. 6. 7. 8.]
    

### 76. Consider a one-dimensional array Z, build a two-dimensional array whose first row is (Z[0],Z[1],Z[2]) and each subsequent row is shifted by 1 (last row should be (Z[-3],Z[-2],Z[-1]) (★★★)



```python
import numpy as np

# Sample one-dimensional array Z
Z = np.array([1, 2, 3, 4, 5])

# Number of elements in each row
n = 3

# Build the two-dimensional array
result = np.lib.stride_tricks.sliding_window_view(Z, (n,))
result = result.T.copy()

print(result)

```

    [[1 2 3]
     [2 3 4]
     [3 4 5]]
    

### 77. How to negate a boolean, or to change the sign of a float inplace? (★★★)


```python
# Original boolean value
boolean_value = True

# Negate the boolean in-place
boolean_value = not boolean_value

print("Negated Boolean:", boolean_value)

```

    Negated Boolean: False
    

### 78. Consider 2 sets of points P0,P1 describing lines (2d) and a point p, how to compute distance from p to each line i (P0[i],P1[i])? (★★★)


```python
import numpy as np

def distance_from_point_to_line(P0, P1, p):
    # Calculate the direction vector of the line
    v = P1 - P0

    # Calculate the vector from P0 to the point p
    w = p - P0

    # Calculate the projection of w onto v
    t = np.dot(w, v) / np.dot(v, v)

    # Calculate the closest point on the line to the point p
    closest_point = P0 + t * v

    # Calculate the distance from p to the closest point on the line
    distance = np.linalg.norm(p - closest_point)

    return distance

# Sample points and lines
P0 = np.array([[1, 2], [2, 3], [3, 4]])
P1 = np.array([[4, 5], [5, 6], [6, 7]])
p = np.array([2, 5])

# Calculate distances to each line
distances = [distance_from_point_to_line(P0[i], P1[i], p) for i in range(len(P0))]

print("Distances from point to lines:")
for i, distance in enumerate(distances):
    print(f"Line {i}: {distance}")

```

    Distances from point to lines:
    Line 0: 1.4142135623730951
    Line 1: 1.4142135623730951
    Line 2: 1.4142135623730951
    

### 79. Consider 2 sets of points P0,P1 describing lines (2d) and a set of points P, how to compute distance from each point j (P[j]) to each line i (P0[i],P1[i])? (★★★)


```python
import numpy as np

def distance_from_point_to_line(P0, P1, P):
    # Calculate the direction vector of the line
    v = P1 - P0

    # Calculate the vector from P0 to the point P
    w = P - P0

    # Calculate the projection of w onto v
    t = np.dot(w, v) / np.dot(v, v)

    # Calculate the closest point on the line to the point P
    closest_point = P0 + t * v

    # Calculate the distance from P to the closest point on the line
    distance = np.linalg.norm(P - closest_point, axis=1)

    return distance

# Sample points and lines
P0 = np.array([[1, 2], [2, 3], [3, 4]])
P1 = np.array([[4, 5], [5, 6], [6, 7]])
P = np.array([[2, 5], [3, 6], [4, 7]])

# Calculate distances from each point to each line
distances = np.array([distance_from_point_to_line(P0[i], P1[i], P) for i in range(len(P0))]).T

print("Distances from points to lines:")
print(distances)

```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    Cell In[139], line 27
         24 P = np.array([[2, 5], [3, 6], [4, 7]])
         26 # Calculate distances from each point to each line
    ---> 27 distances = np.array([distance_from_point_to_line(P0[i], P1[i], P) for i in range(len(P0))]).T
         29 print("Distances from points to lines:")
         30 print(distances)
    

    Cell In[139], line 27, in <listcomp>(.0)
         24 P = np.array([[2, 5], [3, 6], [4, 7]])
         26 # Calculate distances from each point to each line
    ---> 27 distances = np.array([distance_from_point_to_line(P0[i], P1[i], P) for i in range(len(P0))]).T
         29 print("Distances from points to lines:")
         30 print(distances)
    

    Cell In[139], line 14, in distance_from_point_to_line(P0, P1, P)
         11 t = np.dot(w, v) / np.dot(v, v)
         13 # Calculate the closest point on the line to the point P
    ---> 14 closest_point = P0 + t * v
         16 # Calculate the distance from P to the closest point on the line
         17 distance = np.linalg.norm(P - closest_point, axis=1)
    

    ValueError: operands could not be broadcast together with shapes (3,) (2,) 


### 80. Consider an arbitrary array, write a function that extract a subpart with a fixed shape and centered on a given element (pad with a fill value when necessary) (★★★)


```python
import numpy as np

def extract_subpart(arr, center, shape, fill_value=0):
    subpart = np.full(shape, fill_value, dtype=arr.dtype)
    start = np.maximum(center - np.array(shape) // 2, 0)
    end = np.minimum(center + (np.array(shape) + 1) // 2, arr.shape)
    subpart_start = np.maximum(np.array(shape) // 2 - center + start, 0)
    subpart[subpart_start[0]:subpart_start[0]+end[0]-start[0], subpart_start[1]:subpart_start[1]+end[1]-start[1]] = arr[start[0]:end[0], start[1]:end[1]]
    return subpart

# Sample input array
input_array = np.array([[1, 2, 3],
                       [4, 5, 6],
                       [7, 8, 9]])

# Center point for subpart
center_point = np.array([1, 1])

# Shape of the subpart
subpart_shape = (3, 3)

# Fill value for padding
fill_value = 0

# Extract subpart
subpart = extract_subpart(input_array, center_point, subpart_shape, fill_value)

print("Original Array:")
print(input_array)
print("Subpart:")
print(subpart)


```

    Original Array:
    [[1 2 3]
     [4 5 6]
     [7 8 9]]
    Subpart:
    [[1 2 3]
     [4 5 6]
     [7 8 9]]
    

### 81. Consider an array Z = [1,2,3,4,5,6,7,8,9,10,11,12,13,14], how to generate an array R = [[1,2,3,4], [2,3,4,5], [3,4,5,6], ..., [11,12,13,14]]? (★★★)


```python
import numpy as np

# Given array Z
Z = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14])

# Define the size of the rolling window
window_size = 4

# Generate the array R using a rolling window
R = np.lib.stride_tricks.sliding_window_view(Z, (window_size,))

print(R)

```

    [[ 1  2  3  4]
     [ 2  3  4  5]
     [ 3  4  5  6]
     [ 4  5  6  7]
     [ 5  6  7  8]
     [ 6  7  8  9]
     [ 7  8  9 10]
     [ 8  9 10 11]
     [ 9 10 11 12]
     [10 11 12 13]
     [11 12 13 14]]
    

### 82. Compute a matrix rank (★★★)



```python
W = np.random.uniform(0,1,(10,10))
X, Y, Z = np.linalg.svd(W) # Singular Value Decomposition
rank = np.sum(S > 1e-10)
print(rank)
```

    10
    

### 83. How to find the most frequent value in an array?


```python
import numpy as np

# Sample array
array = np.array([1, 2, 2, 3, 3, 3, 4, 4, 4, 4, 5])

# Use np.bincount to count occurrences of each value
counts = np.bincount(array)

# Find the value with the maximum count
most_frequent_value = np.argmax(counts)

print("Array:")
print(array)
print("Most frequent value:", most_frequent_value)

```

    Array:
    [1 2 2 3 3 3 4 4 4 4 5]
    Most frequent value: 4
    

### 84. Extract all the contiguous 3x3 blocks from a random 10x10 matrix (★★★)



```python
import numpy as np

# Create a random 10x10 matrix for demonstration
matrix = np.random.rand(10, 10)

# Define the block size
block_size = (3, 3)

# Initialize an empty list to store the extracted blocks
blocks = []

# Iterate through the matrix to extract blocks
for i in range(10 - block_size[0] + 1):
    for j in range(10 - block_size[1] + 1):
        block = matrix[i:i + block_size[0], j:j + block_size[1]]
        blocks.append(block)

# Convert the list of blocks to a NumPy array
block_array = np.array(blocks)

# Print the extracted blocks
for i, block in enumerate(block_array):
    print(f"Block {i + 1}:\n{block}\n")

```

    Block 1:
    [[2.74357870e-04 4.37420036e-01 4.26519780e-03]
     [7.39222185e-01 5.76026491e-01 8.85128815e-01]
     [8.62740550e-01 4.47275671e-01 6.29571656e-02]]
    
    Block 2:
    [[0.43742004 0.0042652  0.15238325]
     [0.57602649 0.88512881 0.57851517]
     [0.44727567 0.06295717 0.19744991]]
    
    Block 3:
    [[0.0042652  0.15238325 0.43309937]
     [0.88512881 0.57851517 0.51382945]
     [0.06295717 0.19744991 0.2907663 ]]
    
    Block 4:
    [[0.15238325 0.43309937 0.2036082 ]
     [0.57851517 0.51382945 0.22060983]
     [0.19744991 0.2907663  0.39156828]]
    
    Block 5:
    [[0.43309937 0.2036082  0.4610235 ]
     [0.51382945 0.22060983 0.32918945]
     [0.2907663  0.39156828 0.0711189 ]]
    
    Block 6:
    [[0.2036082  0.4610235  0.96947688]
     [0.22060983 0.32918945 0.84370257]
     [0.39156828 0.0711189  0.74630664]]
    
    Block 7:
    [[0.4610235  0.96947688 0.66305821]
     [0.32918945 0.84370257 0.6719653 ]
     [0.0711189  0.74630664 0.9233461 ]]
    
    Block 8:
    [[0.96947688 0.66305821 0.84828586]
     [0.84370257 0.6719653  0.45103064]
     [0.74630664 0.9233461  0.99542272]]
    
    Block 9:
    [[0.73922218 0.57602649 0.88512881]
     [0.86274055 0.44727567 0.06295717]
     [0.10090742 0.76548618 0.04733919]]
    
    Block 10:
    [[0.57602649 0.88512881 0.57851517]
     [0.44727567 0.06295717 0.19744991]
     [0.76548618 0.04733919 0.28301745]]
    
    Block 11:
    [[0.88512881 0.57851517 0.51382945]
     [0.06295717 0.19744991 0.2907663 ]
     [0.04733919 0.28301745 0.23708261]]
    
    Block 12:
    [[0.57851517 0.51382945 0.22060983]
     [0.19744991 0.2907663  0.39156828]
     [0.28301745 0.23708261 0.49486842]]
    
    Block 13:
    [[0.51382945 0.22060983 0.32918945]
     [0.2907663  0.39156828 0.0711189 ]
     [0.23708261 0.49486842 0.82460651]]
    
    Block 14:
    [[0.22060983 0.32918945 0.84370257]
     [0.39156828 0.0711189  0.74630664]
     [0.49486842 0.82460651 0.51104284]]
    
    Block 15:
    [[0.32918945 0.84370257 0.6719653 ]
     [0.0711189  0.74630664 0.9233461 ]
     [0.82460651 0.51104284 0.23642923]]
    
    Block 16:
    [[0.84370257 0.6719653  0.45103064]
     [0.74630664 0.9233461  0.99542272]
     [0.51104284 0.23642923 0.86557043]]
    
    Block 17:
    [[0.86274055 0.44727567 0.06295717]
     [0.10090742 0.76548618 0.04733919]
     [0.09731063 0.87235303 0.49564422]]
    
    Block 18:
    [[0.44727567 0.06295717 0.19744991]
     [0.76548618 0.04733919 0.28301745]
     [0.87235303 0.49564422 0.47394978]]
    
    Block 19:
    [[0.06295717 0.19744991 0.2907663 ]
     [0.04733919 0.28301745 0.23708261]
     [0.49564422 0.47394978 0.98490612]]
    
    Block 20:
    [[0.19744991 0.2907663  0.39156828]
     [0.28301745 0.23708261 0.49486842]
     [0.47394978 0.98490612 0.3748304 ]]
    
    Block 21:
    [[0.2907663  0.39156828 0.0711189 ]
     [0.23708261 0.49486842 0.82460651]
     [0.98490612 0.3748304  0.03563726]]
    
    Block 22:
    [[0.39156828 0.0711189  0.74630664]
     [0.49486842 0.82460651 0.51104284]
     [0.3748304  0.03563726 0.09594861]]
    
    Block 23:
    [[0.0711189  0.74630664 0.9233461 ]
     [0.82460651 0.51104284 0.23642923]
     [0.03563726 0.09594861 0.8371435 ]]
    
    Block 24:
    [[0.74630664 0.9233461  0.99542272]
     [0.51104284 0.23642923 0.86557043]
     [0.09594861 0.8371435  0.89412221]]
    
    Block 25:
    [[0.10090742 0.76548618 0.04733919]
     [0.09731063 0.87235303 0.49564422]
     [0.37591812 0.18228854 0.20558448]]
    
    Block 26:
    [[0.76548618 0.04733919 0.28301745]
     [0.87235303 0.49564422 0.47394978]
     [0.18228854 0.20558448 0.57674958]]
    
    Block 27:
    [[0.04733919 0.28301745 0.23708261]
     [0.49564422 0.47394978 0.98490612]
     [0.20558448 0.57674958 0.21221706]]
    
    Block 28:
    [[0.28301745 0.23708261 0.49486842]
     [0.47394978 0.98490612 0.3748304 ]
     [0.57674958 0.21221706 0.06199861]]
    
    Block 29:
    [[0.23708261 0.49486842 0.82460651]
     [0.98490612 0.3748304  0.03563726]
     [0.21221706 0.06199861 0.88289799]]
    
    Block 30:
    [[0.49486842 0.82460651 0.51104284]
     [0.3748304  0.03563726 0.09594861]
     [0.06199861 0.88289799 0.64114068]]
    
    Block 31:
    [[0.82460651 0.51104284 0.23642923]
     [0.03563726 0.09594861 0.8371435 ]
     [0.88289799 0.64114068 0.12353638]]
    
    Block 32:
    [[0.51104284 0.23642923 0.86557043]
     [0.09594861 0.8371435  0.89412221]
     [0.64114068 0.12353638 0.21613785]]
    
    Block 33:
    [[0.09731063 0.87235303 0.49564422]
     [0.37591812 0.18228854 0.20558448]
     [0.52047096 0.58738421 0.21330329]]
    
    Block 34:
    [[0.87235303 0.49564422 0.47394978]
     [0.18228854 0.20558448 0.57674958]
     [0.58738421 0.21330329 0.85822607]]
    
    Block 35:
    [[0.49564422 0.47394978 0.98490612]
     [0.20558448 0.57674958 0.21221706]
     [0.21330329 0.85822607 0.7267566 ]]
    
    Block 36:
    [[0.47394978 0.98490612 0.3748304 ]
     [0.57674958 0.21221706 0.06199861]
     [0.85822607 0.7267566  0.07307837]]
    
    Block 37:
    [[0.98490612 0.3748304  0.03563726]
     [0.21221706 0.06199861 0.88289799]
     [0.7267566  0.07307837 0.92003029]]
    
    Block 38:
    [[0.3748304  0.03563726 0.09594861]
     [0.06199861 0.88289799 0.64114068]
     [0.07307837 0.92003029 0.27302796]]
    
    Block 39:
    [[0.03563726 0.09594861 0.8371435 ]
     [0.88289799 0.64114068 0.12353638]
     [0.92003029 0.27302796 0.04893145]]
    
    Block 40:
    [[0.09594861 0.8371435  0.89412221]
     [0.64114068 0.12353638 0.21613785]
     [0.27302796 0.04893145 0.94670972]]
    
    Block 41:
    [[0.37591812 0.18228854 0.20558448]
     [0.52047096 0.58738421 0.21330329]
     [0.21325141 0.3880593  0.82475422]]
    
    Block 42:
    [[0.18228854 0.20558448 0.57674958]
     [0.58738421 0.21330329 0.85822607]
     [0.3880593  0.82475422 0.82718735]]
    
    Block 43:
    [[0.20558448 0.57674958 0.21221706]
     [0.21330329 0.85822607 0.7267566 ]
     [0.82475422 0.82718735 0.9989492 ]]
    
    Block 44:
    [[0.57674958 0.21221706 0.06199861]
     [0.85822607 0.7267566  0.07307837]
     [0.82718735 0.9989492  0.02633451]]
    
    Block 45:
    [[0.21221706 0.06199861 0.88289799]
     [0.7267566  0.07307837 0.92003029]
     [0.9989492  0.02633451 0.68920067]]
    
    Block 46:
    [[0.06199861 0.88289799 0.64114068]
     [0.07307837 0.92003029 0.27302796]
     [0.02633451 0.68920067 0.21140928]]
    
    Block 47:
    [[0.88289799 0.64114068 0.12353638]
     [0.92003029 0.27302796 0.04893145]
     [0.68920067 0.21140928 0.62382985]]
    
    Block 48:
    [[0.64114068 0.12353638 0.21613785]
     [0.27302796 0.04893145 0.94670972]
     [0.21140928 0.62382985 0.30689698]]
    
    Block 49:
    [[0.52047096 0.58738421 0.21330329]
     [0.21325141 0.3880593  0.82475422]
     [0.13988586 0.70519333 0.71883256]]
    
    Block 50:
    [[0.58738421 0.21330329 0.85822607]
     [0.3880593  0.82475422 0.82718735]
     [0.70519333 0.71883256 0.1067147 ]]
    
    Block 51:
    [[0.21330329 0.85822607 0.7267566 ]
     [0.82475422 0.82718735 0.9989492 ]
     [0.71883256 0.1067147  0.89912474]]
    
    Block 52:
    [[0.85822607 0.7267566  0.07307837]
     [0.82718735 0.9989492  0.02633451]
     [0.1067147  0.89912474 0.15162163]]
    
    Block 53:
    [[0.7267566  0.07307837 0.92003029]
     [0.9989492  0.02633451 0.68920067]
     [0.89912474 0.15162163 0.25713604]]
    
    Block 54:
    [[0.07307837 0.92003029 0.27302796]
     [0.02633451 0.68920067 0.21140928]
     [0.15162163 0.25713604 0.19676897]]
    
    Block 55:
    [[0.92003029 0.27302796 0.04893145]
     [0.68920067 0.21140928 0.62382985]
     [0.25713604 0.19676897 0.02153191]]
    
    Block 56:
    [[0.27302796 0.04893145 0.94670972]
     [0.21140928 0.62382985 0.30689698]
     [0.19676897 0.02153191 0.01869365]]
    
    Block 57:
    [[0.21325141 0.3880593  0.82475422]
     [0.13988586 0.70519333 0.71883256]
     [0.51716934 0.89133183 0.21884152]]
    
    Block 58:
    [[0.3880593  0.82475422 0.82718735]
     [0.70519333 0.71883256 0.1067147 ]
     [0.89133183 0.21884152 0.40686634]]
    
    Block 59:
    [[0.82475422 0.82718735 0.9989492 ]
     [0.71883256 0.1067147  0.89912474]
     [0.21884152 0.40686634 0.73325228]]
    
    Block 60:
    [[0.82718735 0.9989492  0.02633451]
     [0.1067147  0.89912474 0.15162163]
     [0.40686634 0.73325228 0.66912825]]
    
    Block 61:
    [[0.9989492  0.02633451 0.68920067]
     [0.89912474 0.15162163 0.25713604]
     [0.73325228 0.66912825 0.15333655]]
    
    Block 62:
    [[0.02633451 0.68920067 0.21140928]
     [0.15162163 0.25713604 0.19676897]
     [0.66912825 0.15333655 0.89147717]]
    
    Block 63:
    [[0.68920067 0.21140928 0.62382985]
     [0.25713604 0.19676897 0.02153191]
     [0.15333655 0.89147717 0.75305524]]
    
    Block 64:
    [[0.21140928 0.62382985 0.30689698]
     [0.19676897 0.02153191 0.01869365]
     [0.89147717 0.75305524 0.55822348]]
    
    

### 85. Create a 2D array subclass such that Z[i,j] == Z[j,i] (★★★)



```python
import numpy as np

class SymmetricArray(np.ndarray):
    def __new__(cls, input_array):
        # Create a view of the input array
        obj = np.asarray(input_array).view(cls)
        return obj

    def __getitem__(self, indices):
        # Ensure that Z[i, j] is equal to Z[j, i]
        i, j = indices
        return super(SymmetricArray, self).__getitem__((i, j))

    def __setitem__(self, indices, value):
        # Ensure that Z[i, j] is equal to Z[j, i] when setting values
        i, j = indices
        super(SymmetricArray, self).__setitem__((i, j), value)
        super(SymmetricArray, self).__setitem__((j, i), value)

# Create a regular NumPy array
original_array = np.array([[1, 2, 3],
                          [2, 4, 5],
                          [3, 5, 6]])

# Create a symmetric array using the custom subclass
symmetric_array = SymmetricArray(original_array)

# Access and modify elements
print("Original Array:")
print(original_array)
print("Symmetric Array:")
print(symmetric_array)

symmetric_array[0, 2] = 9
print("Modified Symmetric Array:")
print(symmetric_array)

```

    Original Array:
    [[1 2 3]
     [2 4 5]
     [3 5 6]]
    Symmetric Array:
    [[1 2 3]
     [2 4 5]
     [3 5 6]]
    Modified Symmetric Array:
    [[1 2 9]
     [2 4 5]
     [9 5 6]]
    

### 86. Consider a set of p matrices wich shape (n,n) and a set of p vectors with shape (n,1). How to compute the sum of of the p matrix products at once? (result has shape (n,1)) (★★★)


```python
Q, n = 10, 20
R = np.ones((Q,n,n))
S = np.ones((Q,n,1))
T = np.tensordot(R, S, axes=[[0, 2], [0, 1]])
print(T)
```

    [[200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]
     [200.]]
    

### 87. Consider a 16x16 array, how to get the block-sum (block size is 4x4)? (★★★)


```python
import numpy as np

# Create a random 16x16 array for demonstration
array = np.random.rand(16, 16)

# Define the block size
block_size = 4

# Calculate the number of blocks in each dimension
num_blocks = array.shape[0] // block_size

# Initialize an empty array to store the block-sums
block_sums = np.empty((num_blocks, num_blocks))

# Iterate through the blocks and calculate the block-sums
for i in range(num_blocks):
    for j in range(num_blocks):
        block = array[i * block_size:(i + 1) * block_size, j * block_size:(j + 1) * block_size]
        block_sums[i, j] = np.sum(block)

# Print the block-sums
print("Block-Sums:")
print(block_sums)

```

    Block-Sums:
    [[ 6.77995284  6.81442368  8.83340927 10.2901112 ]
     [ 9.19672976  9.01442582  8.93221942  7.54244202]
     [ 9.33548625  7.63025325  7.75195876  8.35885334]
     [ 8.03487594  7.42608166  8.37169893  7.7173131 ]]
    

### 88. How to implement the Game of Life using numpy arrays? (★★★)



```python
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

def update(grid):
    # Copy the grid to calculate the next generation
    new_grid = grid.copy()
    rows, cols = grid.shape

    for i in range(rows):
        for j in range(cols):
            # Count the live neighbors
            neighbor_sum = np.sum(grid[i - 1:i + 2, j - 1:j + 2]) - grid[i, j]

            # Apply the Game of Life rules
            if grid[i, j] == 1:  # Cell is alive
                if neighbor_sum < 2 or neighbor_sum > 3:
                    new_grid[i, j] = 0
            else:  # Cell is dead
                if neighbor_sum == 3:
                    new_grid[i, j] = 1

    return new_grid

# Initialize a random grid
grid = np.random.choice([0, 1], size=(50, 50))

fig, ax = plt.subplots()
im = ax.imshow(grid, cmap='binary')

def animate(frame):
    global grid
    grid = update(grid)
    im.set_data(grid)
    return im,

ani = animation.FuncAnimation(fig, animate, frames=100, blit=True)
plt.show()

```


    
![png](output_284_0.png)
    


### 89. How to get the n largest values of an array (★★★)


```python
import numpy as np

# Create a NumPy array for demonstration
arr = np.array([4, 9, 1, 7, 3, 8, 5, 2, 6])

# Specify the number of largest values to retrieve
n = 3

# Use numpy.partition to partially sort the array
partitioned_indices = np.argpartition(-arr, n)  # Use negative values for largest elements

# Get the indices of the n largest values
n_largest_indices = partitioned_indices[:n]

# Get the n largest values from the original array
n_largest_values = arr[n_largest_indices]

print("Original Array:", arr)
print(f"{n} Largest Values:", n_largest_values)

```

    Original Array: [4 9 1 7 3 8 5 2 6]
    3 Largest Values: [9 8 7]
    

### 90. Given an arbitrary number of vectors, build the cartesian product (every combinations of every item) (★★★)


```python
def cartesian(arrays):
    arrays = [np.asarray(a) for a in arrays]
    shape = (len(x) for x in arrays)

    ix = np.indices(shape, dtype=int)
    ix = ix.reshape(len(arrays), -1).T

    for n, arr in enumerate(arrays):
        ix[:, n] = arrays[n][ix[:, n]]

    return ix

print (cartesian(([1, 2, 3], [4, 5], [6, 7])))
```

    [[1 4 6]
     [1 4 7]
     [1 5 6]
     [1 5 7]
     [2 4 6]
     [2 4 7]
     [2 5 6]
     [2 5 7]
     [3 4 6]
     [3 4 7]
     [3 5 6]
     [3 5 7]]
    

### 91. How to create a record array from a regular array? (★★★)


```python
Z = np.array([("Hello", 2.5, 3),
              ("World", 3.6, 2)])
R = np.core.records.fromarrays(Z.T, 
                               names='col1, col2, col3',
                               formats = 'S8, f8, i8')
print(R)
```

    [(b'Hello', 2.5, 3) (b'World', 3.6, 2)]
    

### 92. Consider a large vector Z, compute Z to the power of 3 using 3 different methods (★★★)


```python
import numpy as np

# Create a large vector Z (replace with your own data)
Z = np.random.rand(1000000)  # Example vector with 1 million elements

# Method 1: Using NumPy's power function
result1 = np.power(Z, 3)

# Method 2: Using the ** operator
result2 = Z ** 3

# Method 3: Using NumPy's multiply function
result3 = np.multiply(np.multiply(Z, Z), Z)

# Verify if all methods produce the same result
assert np.allclose(result1, result2) and np.allclose(result2, result3)

# Print a portion of the result for verification
print("Method 1 Result (Sample):", result1[:10])



```

    Method 1 Result (Sample): [2.74610538e-03 7.68300033e-01 7.94421973e-01 1.46643316e-03
     4.08494257e-04 4.01428255e-02 3.09265668e-01 3.73131807e-06
     8.22782209e-01 2.89399741e-02]
    

### 93. Consider two arrays A and B of shape (8,3) and (2,2). How to find rows of A that contain elements of each row of B regardless of the order of the elements in B? (★★★)


```python
import numpy as np

# Create two example arrays A and B
A = np.array([[1, 2, 3],
              [4, 5, 6],
              [7, 8, 9],
              [3, 2, 1],
              [9, 8, 7],
              [6, 5, 4],
              [2, 1, 3],
              [0, 0, 0]])

B = np.array([[1, 2],
              [7, 8]])

# Find the sorted unique elements in B
sorted_unique_B = np.sort(B, axis=1)
sorted_unique_B = np.unique(sorted_unique_B, axis=0)

# Find rows in A that contain elements of each row in sorted_unique_B
matching_rows = np.all(np.isin(A, sorted_unique_B), axis=1)

# Extract and print the matching rows from A
result = A[matching_rows]

print("Array A:")
print(A)
print("\nArray B:")
print(B)
print("\nRows of A that contain elements of each row of B:")
print(result)

```

    Array A:
    [[1 2 3]
     [4 5 6]
     [7 8 9]
     [3 2 1]
     [9 8 7]
     [6 5 4]
     [2 1 3]
     [0 0 0]]
    
    Array B:
    [[1 2]
     [7 8]]
    
    Rows of A that contain elements of each row of B:
    []
    

### 94. Considering a 10x3 matrix, extract rows with unequal values (e.g. [2,2,3]) (★★★)



```python
import numpy as np

# Create a 10x3 matrix (replace with your own data)
matrix = np.array([[2, 2, 2],
                  [1, 2, 3],
                  [3, 3, 3],
                  [4, 4, 4],
                  [1, 1, 1],
                  [2, 2, 2],
                  [5, 6, 5],
                  [7, 8, 9],
                  [0, 1, 2],
                  [3, 3, 3]])

# Check if each element in a row is not equal to the first element
unequal_rows = ~np.all(matrix == matrix[:, 0][:, np.newaxis], axis=1)

# Extract rows with unequal values
result = matrix[unequal_rows]

print("Original Matrix:")
print(matrix)
print("\nRows with Unequal Values:")
print(result)

  

```

    Original Matrix:
    [[2 2 2]
     [1 2 3]
     [3 3 3]
     [4 4 4]
     [1 1 1]
     [2 2 2]
     [5 6 5]
     [7 8 9]
     [0 1 2]
     [3 3 3]]
    
    Rows with Unequal Values:
    [[1 2 3]
     [5 6 5]
     [7 8 9]
     [0 1 2]]
    

### 95. Convert a vector of ints into a matrix binary representation (★★★)


```python
I = np.array([0, 1, 2, 3, 15, 16, 32, 64, 128])
B = ((I.reshape(-1,1) & (2**np.arange(8))) != 0).astype(int)
print(B[:,::-1])

# Author: Daniel T. McDonald

I = np.array([0, 1, 2, 3, 15, 16, 32, 64, 128], dtype=np.uint8)
print(np.unpackbits(I[:, np.newaxis], axis=1))
```

    [[0 0 0 0 0 0 0 0]
     [0 0 0 0 0 0 0 1]
     [0 0 0 0 0 0 1 0]
     [0 0 0 0 0 0 1 1]
     [0 0 0 0 1 1 1 1]
     [0 0 0 1 0 0 0 0]
     [0 0 1 0 0 0 0 0]
     [0 1 0 0 0 0 0 0]
     [1 0 0 0 0 0 0 0]]
    [[0 0 0 0 0 0 0 0]
     [0 0 0 0 0 0 0 1]
     [0 0 0 0 0 0 1 0]
     [0 0 0 0 0 0 1 1]
     [0 0 0 0 1 1 1 1]
     [0 0 0 1 0 0 0 0]
     [0 0 1 0 0 0 0 0]
     [0 1 0 0 0 0 0 0]
     [1 0 0 0 0 0 0 0]]
    

### 96. Given a two dimensional array, how to extract unique rows? (★★★)


```python
import numpy as np

# Create a two-dimensional array (replace with your own data)
array_2d = np.array([[1, 2, 3],
                    [4, 5, 6],
                    [1, 2, 3],
                    [7, 8, 9],
                    [4, 5, 6]])

# Use numpy.unique with the axis parameter to get unique rows
unique_rows = np.unique(array_2d, axis=0)

print("Original 2D Array:")
print(array_2d)
print("\nUnique Rows:")
print(unique_rows)

```

    Original 2D Array:
    [[1 2 3]
     [4 5 6]
     [1 2 3]
     [7 8 9]
     [4 5 6]]
    
    Unique Rows:
    [[1 2 3]
     [4 5 6]
     [7 8 9]]
    

### 97. Considering 2 vectors A & B, write the einsum equivalent of inner, outer, sum, and mul function (★★★)


```python
A = np.random.uniform(0,1,10)
B = np.random.uniform(0,1,10)

np.einsum('i->', A)       # np.sum(A)
np.einsum('i,i->i', A, B) # A * B
np.einsum('i,i', A, B)    # np.inner(A, B)
np.einsum('i,j->ij', A, B)    # np.outer(A, B)
```




    array([[0.0313039 , 0.28224819, 0.31629659, 0.27214441, 0.04247131,
            0.12578389, 0.01977339, 0.30019119, 0.0672    , 0.13631293],
           [0.04245511, 0.38279185, 0.42896911, 0.36908885, 0.05760062,
            0.17059116, 0.02681715, 0.40712657, 0.09113827, 0.1848709 ],
           [0.09084556, 0.81909904, 0.91790928, 0.78977734, 0.12325397,
            0.36503143, 0.05738342, 0.87117055, 0.19501792, 0.39558725],
           [0.08437092, 0.76072117, 0.85248913, 0.73348926, 0.11446956,
            0.33901533, 0.05329366, 0.8090815 , 0.18111883, 0.36739342],
           [0.02203407, 0.19866774, 0.22263359, 0.19155593, 0.02989454,
            0.08853626, 0.01391802, 0.21129738, 0.04730047, 0.0959474 ],
           [0.01725018, 0.1555344 , 0.17429696, 0.14996666, 0.02340405,
            0.0693139 , 0.01089624, 0.16542199, 0.03703093, 0.07511598],
           [0.002554  , 0.02302785, 0.02580577, 0.02220351, 0.00346512,
            0.01026236, 0.00161326, 0.02449177, 0.00548266, 0.0111214 ],
           [0.02133208, 0.19233836, 0.21554068, 0.18545312, 0.02894212,
            0.08571557, 0.0134746 , 0.20456563, 0.04579352, 0.0928906 ],
           [0.0384854 , 0.34699938, 0.3888589 , 0.33457767, 0.05221475,
            0.15464025, 0.02430965, 0.36905871, 0.0826165 , 0.16758478],
           [0.02332374, 0.21029594, 0.23566453, 0.20276787, 0.03164429,
            0.09371837, 0.01473265, 0.2236648 , 0.05006901, 0.10156329]])



### 98. Considering a path described by two vectors (X,Y), how to sample it using equidistant samples (★★★)?


```python
import numpy as np

# Create two vectors X and Y describing the path
X = np.array([0, 1, 3, 6, 9, 11, 12])
Y = np.array([0, 2, 3, 4, 3, 2, 0])

# Calculate the total path length
path_length = np.cumsum(np.sqrt(np.diff(X) ** 2 + np.diff(Y) ** 2))
path_length = np.insert(path_length, 0, 0)  # Insert a zero at the beginning

# Define the number of equidistant samples
num_samples = 20

# Linearly interpolate the path at equidistant intervals
sampled_indices = np.linspace(0, path_length[-1], num_samples)
sampled_X = np.interp(sampled_indices, path_length, X)
sampled_Y = np.interp(sampled_indices, path_length, Y)

# Print the sampled path
sampled_path = np.column_stack((sampled_X, sampled_Y))
print("Sampled Path:")
print(sampled_path)

```

    Sampled Path:
    [[ 0.          0.        ]
     [ 0.3593909   0.7187818 ]
     [ 0.7187818   1.43756361]
     [ 1.15634541  2.0781727 ]
     [ 1.87512721  2.43756361]
     [ 2.59390901  2.79695451]
     [ 3.33165869  3.1105529 ]
     [ 4.09404192  3.36468064]
     [ 4.85642515  3.61880838]
     [ 5.61880838  3.87293613]
     [ 6.38119162  3.87293613]
     [ 7.14357485  3.61880838]
     [ 7.90595808  3.36468064]
     [ 8.66834131  3.1105529 ]
     [ 9.40609099  2.79695451]
     [10.12487279  2.43756361]
     [10.84365459  2.0781727 ]
     [11.2812182   1.43756361]
     [11.6406091   0.7187818 ]
     [12.          0.        ]]
    

### 99. Given an integer n and a 2D array X, select from X the rows which can be interpreted as draws from a multinomial distribution with n degrees, i.e., the rows which only contain integers and which sum to n. (★★★)


```python
X = np.asarray([[1.0, 0.0, 3.0, 8.0],
                [2.0, 0.0, 1.0, 1.0],
                [1.5, 2.5, 1.0, 0.0]])
n = 4
M = np.logical_and.reduce(np.mod(X, 1) == 0, axis=-1)
M &= (X.sum(axis=-1) == n)
print(X[M])
```

    [[2. 0. 1. 1.]]
    

### 100. Compute bootstrapped 95% confidence intervals for the mean of a 1D array X (i.e., resample the elements of an array with replacement N times, compute the mean of each sample, and then compute percentiles over the means). (★★★)


```python
import numpy as np

# Example 1D array X (replace with your own data)
X = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])

# Number of bootstraps
num_bootstraps = 1000

# Number of samples in each bootstrap (same as the original dataset)
sample_size = len(X)

# Initialize an array to store bootstrapped means
bootstrap_means = np.empty(num_bootstraps)

# Perform bootstrapping
for i in range(num_bootstraps):
    # Resample the array with replacement
    resampled_data = np.random.choice(X, size=sample_size, replace=True)
    # Calculate the mean of the resampled data
    bootstrap_means[i] = np.mean(resampled_data)

# Calculate the 2.5th and 97.5th percentiles to get the 95% confidence interval
confidence_interval = np.percentile(bootstrap_means, [2.5, 97.5])

print("Original 1D Array X:")
print(X)
print("\n95% Confidence Interval for the Mean (Bootstrapped):")
print(confidence_interval)

```

    Original 1D Array X:
    [ 1  2  3  4  5  6  7  8  9 10]
    
    95% Confidence Interval for the Mean (Bootstrapped):
    [3.8 7.3]
    


```python

```


```python

```
